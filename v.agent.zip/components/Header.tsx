import React from 'react';
import { type ActiveView } from '../types';
import { VAgentLogoIcon, MoonIcon, SunIcon, SearchIcon, RadarIcon, BrainCircuitIcon } from './ui/icons';

interface HeaderProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  theme: string;
  toggleTheme: () => void;
  onSearchClick: () => void;
}

const NavItem: React.FC<{
    view: ActiveView;
    currentView: ActiveView;
    onClick: (view: ActiveView) => void;
    children: React.ReactNode;
    isMobile?: boolean;
}> = ({ view, currentView, onClick, children, isMobile = false }) => {
    const isActive = view === currentView;
    const baseClasses = `text-sm font-medium rounded-md transition-colors duration-200 flex items-center gap-2 ${isMobile ? 'p-2 justify-center flex-col text-xs' : 'px-3 py-2'}`;
    const activeClasses = 'bg-primary-500 text-white';
    const inactiveClasses = 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700';

    return (
        <button
            onClick={() => onClick(view)}
            className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
        >
            {children}
        </button>
    );
};

const Header: React.FC<HeaderProps> = ({ activeView, setActiveView, theme, toggleTheme, onSearchClick }) => {
  return (
    <header className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm sticky top-0 z-40 w-full border-b border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-4">
             <div onClick={() => setActiveView('dashboard')} className="flex items-center space-x-2 cursor-pointer">
              <VAgentLogoIcon className="h-8 w-auto" />
              <span className="text-xl font-bold text-gray-900 dark:text-white">V.agent</span>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-2">
            <NavItem view="dashboard" currentView={activeView} onClick={setActiveView}>Home</NavItem>
            <NavItem view="tools" currentView={activeView} onClick={setActiveView}>All Tools</NavItem>
            <NavItem view="radar" currentView={activeView} onClick={setActiveView}><RadarIcon className="h-5 w-5"/>Launch Radar</NavItem>
            <NavItem view="discover" currentView={activeView} onClick={setActiveView}><BrainCircuitIcon className="h-5 w-5"/>Agents</NavItem>
            <button
                onClick={onSearchClick}
                className="px-3 py-2 text-sm font-medium rounded-md text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 flex items-center space-x-2 transition-colors"
                aria-label="Open search"
            >
                <SearchIcon className="h-5 w-5" />
                <span>Search</span>
            </button>
          </div>
          <div className="flex items-center">
            <button
              onClick={toggleTheme}
              className="p-2 rounded-full text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-gray-100 dark:focus:ring-offset-gray-800 focus:ring-primary-500 transition-colors"
              aria-label="Toggle theme"
            >
              {theme === 'dark' ? (
                <SunIcon className="h-6 w-6" />
              ) : (
                <MoonIcon className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
        <div className="md:hidden pb-4 flex justify-around items-center border-t border-gray-200 dark:border-gray-800 pt-2">
            <NavItem view="dashboard" currentView={activeView} onClick={setActiveView} isMobile>Home</NavItem>
            <NavItem view="tools" currentView={activeView} onClick={setActiveView} isMobile>Tools</NavItem>
            <NavItem view="radar" currentView={activeView} onClick={setActiveView} isMobile><RadarIcon className="h-5 w-5"/>Radar</NavItem>
             <NavItem view="discover" currentView={activeView} onClick={setActiveView} isMobile><BrainCircuitIcon className="h-5 w-5"/>Agents</NavItem>
            <button
                onClick={onSearchClick}
                className="p-2 rounded-full text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 flex flex-col items-center gap-1 text-xs font-medium"
                aria-label="Open search"
            >
                <SearchIcon className="h-5 w-5" />
                Search
            </button>
        </div>
      </div>
    </header>
  );
};

export default Header;