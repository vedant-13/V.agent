
import React, { useState, useEffect, useRef } from 'react';
import { type SearchMessage } from '../types';
import { searchAITools } from '../services/geminiService';
import { TOOL_CATEGORIES, TOOL_PRICING } from '../constants';
import { CloseIcon, SendIcon } from './ui/icons';
import SearchMessageComponent from './ui/SearchMessage';
import Spinner from './ui/Spinner';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const initialMessage: SearchMessage = {
  id: 'init-1',
  role: 'model',
  text: 'Hi! I can help you discover the perfect AI tool. What are you looking for today?',
  options: [
    { label: '🔎 General Search', action: 'start-tool-search' },
    { label: '✨ Find Free Tools', action: 'quick-tool-search', payload: { pricing: 'Free' } },
    { label: '🚀 Find Productivity Tools', action: 'quick-tool-search', payload: { category: 'Productivity' } },
  ],
};

const SearchModal: React.FC<SearchModalProps> = ({ isOpen, onClose }) => {
  const [messages, setMessages] = useState<SearchMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [searchState, setSearchState] = useState<{ type?: 'tools'; category?: string; pricing?: string }>({});
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  useEffect(() => {
    if (isOpen) {
      setMessages([initialMessage]);
      setSearchState({});
      setUserInput('');
    }
  }, [isOpen]);

  const performToolSearch = async (query: string) => {
    setIsLoading(true);
    const params = {
        query,
        category: searchState.category || 'All',
        pricing: searchState.pricing || 'All'
    };
    const results = await searchAITools(params);
    const botMessage: SearchMessage = {
      id: `res-${Date.now()}`,
      role: 'model',
      text: results.length > 0 ? `Here are some tools I found for "${params.query || `${params.pricing} ${params.category}` } tools":` : `I couldn't find any tools matching your search. Try being more general.`,
      results: results,
      resultType: 'tools'
    };
    setMessages(prev => [...prev, botMessage, initialMessage]);
    setSearchState({});
    setIsLoading(false);
  }

  const handleAction = async (label: string, action: string, payload?: any) => {
    const userMessage: SearchMessage = { id: Date.now().toString(), role: 'user', text: label };
    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    let botMessage: SearchMessage | null = null;

    switch (action) {
      case 'start-tool-search':
        setSearchState({ type: 'tools' });
        botMessage = {
          id: 'tool-cat-1',
          role: 'model',
          text: 'Great! What category are you interested in?',
          options: [ { label: 'All', action: 'select-tool-category', payload: 'All' }, ...TOOL_CATEGORIES.map(c => ({ label: c, action: 'select-tool-category', payload: c })) ]
        };
        break;

      case 'select-tool-category':
        setSearchState(s => ({ ...s, category: payload }));
        botMessage = {
          id: 'tool-price-1',
          role: 'model',
          text: `Category set to "${payload}". Any pricing preference?`,
          options: [ { label: 'All', action: 'select-tool-pricing', payload: 'All' }, ...TOOL_PRICING.map(p => ({ label: p, action: 'select-tool-pricing', payload: p })) ]
        };
        break;
      
      case 'select-tool-pricing':
        setSearchState(s => ({ ...s, pricing: payload }));
        botMessage = { id: 'tool-query-1', role: 'model', text: `Pricing set to "${payload}". Now, what kind of tool are you looking for? (e.g., "a tool to write emails faster")` };
        break;
      
      case 'quick-tool-search':
        setSearchState({ type: 'tools', pricing: payload.pricing || 'All', category: payload.category || 'All' });
        botMessage = { id: 'tool-query-2', role: 'model', text: `Searching for ${payload.pricing || ''} ${payload.category || ''} tools. What specific feature are you looking for? (e.g., "video editing") If you want to see all tools in this category, just hit send.` };
        break;
    }
    
    if (botMessage) { setMessages(prev => [...prev, botMessage]); }
    setIsLoading(false);
  };
  
  const handleSend = async () => {
    if (isLoading) return;
    const currentInput = userInput;
    
    const userMessage: SearchMessage = { id: Date.now().toString(), role: 'user', text: currentInput || `Show me what you've got!` };
    setMessages(prev => [...prev, userMessage]);
    setUserInput('');
    
    if (searchState.type === 'tools') { await performToolSearch(currentInput); } 
    else {
        const botMessage: SearchMessage = { id: 'err-1', role: 'model', text: "Please select an option to begin your tool search." };
        setMessages(prev => [...prev, botMessage, initialMessage]);
    }
  };
  
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 dark:bg-black/70 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose} role="dialog" aria-modal="true">
      <div 
        className="w-full max-w-2xl h-[85vh] bg-white dark:bg-gray-800 rounded-lg shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center flex-shrink-0">
          <h3 className="font-bold text-lg text-gray-900 dark:text-white">AI Tool Search</h3>
          <button onClick={onClose} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close search">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>

        <div className="flex-grow p-4 overflow-y-auto">
          <div className="space-y-4">
            {messages.map((msg) => ( <SearchMessageComponent key={msg.id} message={msg} onAction={handleAction} /> ))}
             {isLoading && (
                <div className="flex justify-start">
                   <div className="bg-gray-100 dark:bg-gray-700 rounded-lg px-4 py-3 animate-pulse-fast">
                       <Spinner size="sm" />
                   </div>
                </div>
              )}
            <div ref={messagesEndRef} />
          </div>
        </div>

        <footer className="p-4 border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
          <div className="flex items-center space-x-2">
            <input
              type="text"
              value={userInput}
              onChange={(e) => setUserInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder={
                searchState.type === 'tools' ? 'Describe the tool you need...' :
                'Choose an option above...'
              }
              className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
              disabled={isLoading || (!searchState.type)}
            />
            <button
              onClick={handleSend}
              disabled={isLoading || !searchState.type}
              className="bg-primary-500 text-white p-3 rounded-full disabled:bg-primary-300 disabled:cursor-not-allowed hover:bg-primary-600 transition-colors shrink-0"
              aria-label="Send message"
            >
              <SendIcon className="h-6 w-6" />
            </button>
          </div>
        </footer>
      </div>
    </div>
  );
};

export default SearchModal;