import React from 'react';
import { VAgentLogoIcon, MenuIcon, SunIcon, MoonIcon } from './ui/icons';
import { ActiveView } from '../types';

interface MobileHeaderProps {
  onMenuClick: () => void;
  theme: string;
  toggleTheme: () => void;
  setActiveView: (view: ActiveView) => void;
}

const MobileHeader: React.FC<MobileHeaderProps> = ({ onMenuClick, theme, toggleTheme, setActiveView }) => {
  return (
    <header className="flex-shrink-0 bg-ui-background dark:bg-dark_ui-background border-b border-ui-border dark:border-dark_ui-border p-4 flex justify-between items-center">
      <button onClick={onMenuClick} className="p-2 text-gray-700 dark:text-gray-300">
        <MenuIcon className="h-6 w-6" />
      </button>
      <div onClick={() => setActiveView('dashboard')} className="flex items-center space-x-2 cursor-pointer">
        <VAgentLogoIcon className="h-8 w-auto" />
        <span className="text-xl font-bold">V.agent</span>
      </div>
      <button onClick={toggleTheme} className="p-2 text-gray-700 dark:text-gray-300">
        {theme === 'dark' ? <SunIcon className="h-6 w-6" /> : <MoonIcon className="h-6 w-6" />}
      </button>
    </header>
  );
};

export default MobileHeader;