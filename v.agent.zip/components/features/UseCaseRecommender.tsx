import React, { useState } from 'react';
import { recommendToolWorkflow } from '../../services/geminiService';
import { type ToolWorkflow, type RecommendedTool } from '../../types';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import { BrainCircuitIcon, ArrowRightIcon } from '../ui/icons';

const WorkflowStep: React.FC<{ tool: RecommendedTool, index: number, total: number }> = ({ tool, index, total }) => (
    <div className="flex items-center gap-4">
        <div className="flex flex-col items-center">
            <div className="bg-primary-500 text-white rounded-full h-10 w-10 flex items-center justify-center font-bold text-lg">
                {tool.icon}
            </div>
            {index < total - 1 && <div className="w-0.5 h-8 bg-gray-300 dark:bg-gray-600 my-2"></div>}
        </div>
        <div className="bg-white dark:bg-gray-800 p-4 rounded-lg flex-1 shadow">
            <a href={tool.url} target="_blank" rel="noopener noreferrer" className="text-lg font-bold text-gray-900 dark:text-white hover:text-primary-500 hover:underline">{tool.name}</a>
            <p className="text-sm text-gray-600 dark:text-gray-300 mt-1">{tool.reason}</p>
        </div>
    </div>
);


const UseCaseRecommender: React.FC = () => {
    const [goal, setGoal] = useState('');
    const [workflow, setWorkflow] = useState<ToolWorkflow | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!goal.trim()) return;

        setIsLoading(true);
        setError(null);
        setWorkflow(null);

        try {
            const result = await recommendToolWorkflow(goal);
            if (result) {
                setWorkflow(result);
            } else {
                setError("Sorry, I couldn't come up with a workflow for that. Please try rephrasing your goal.");
            }
        } catch (err) {
            setError("An error occurred while generating the workflow. Please try again.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <Section
            title="AI Workflow Recommender"
            subtitle="Describe your goal, and our AI will suggest a sequence of tools to get the job done."
            icon={<BrainCircuitIcon className="h-8 w-8 text-primary-500" />}
        >
            <div className="bg-white dark:bg-gray-800/50 p-6 rounded-lg shadow-lg border border-primary-500/10">
                <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row items-center gap-4">
                    <input
                        type="text"
                        value={goal}
                        onChange={(e) => setGoal(e.target.value)}
                        placeholder="e.g., “I want to create content for my Instagram from blogs”"
                        className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
                        disabled={isLoading}
                    />
                    <button
                        type="submit"
                        disabled={isLoading || !goal.trim()}
                        className="w-full sm:w-auto flex items-center justify-center gap-2 bg-primary-500 text-white font-semibold p-3 rounded-lg hover:bg-primary-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed shrink-0"
                    >
                        {isLoading ? <Spinner size="sm" /> : 'Generate Workflow'}
                    </button>
                </form>

                <div className="mt-6">
                    {isLoading && (
                        <div className="text-center p-8">
                            <p className="text-gray-600 dark:text-gray-300">AI is thinking...</p>
                        </div>
                    )}
                    {error && <p className="text-red-500 text-center">{error}</p>}
                    {workflow && (
                        <div className="animate-fade-in space-y-4">
                            <h3 className="text-xl font-bold text-center mb-4">Your AI-Powered Workflow for: <span className="text-primary-500">"{workflow.goal}"</span></h3>
                            <div className="max-w-md mx-auto">
                                {workflow.workflow.map((tool, index) => (
                                    <WorkflowStep key={index} tool={tool} index={index} total={workflow.workflow.length} />
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </Section>
    );
};

export default UseCaseRecommender;