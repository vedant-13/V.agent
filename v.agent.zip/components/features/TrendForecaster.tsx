import React, { useState, useEffect, useCallback } from 'react';
import { getAITrends } from '../../services/geminiService';
import { type AITrend } from '../../types';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import { TrendingUpIcon } from '../ui/icons';

const TrendCard: React.FC<{ trend: AITrend }> = ({ trend }) => {
    const confidenceColor = {
        High: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
        Medium: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
        Low: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
    };

    return (
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md h-full flex flex-col">
            <div className="flex justify-between items-start">
                <h3 className="text-xl font-bold text-gray-900 dark:text-white">{trend.name}</h3>
                <span className={`text-xs font-bold px-2 py-1 rounded-full ${confidenceColor[trend.confidence]}`}>{trend.confidence}</span>
            </div>
            <p className="mt-3 text-gray-600 dark:text-gray-300 flex-grow">{trend.justification}</p>
        </div>
    );
};

const TrendForecaster: React.FC = () => {
    const [trends, setTrends] = useState<AITrend[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const loadTrends = useCallback(async () => {
        setIsLoading(true);
        setError(null);
        try {
            const data = await getAITrends();
            if (data && data.length > 0) {
                setTrends(data);
            } else {
                setError("The AI couldn't forecast any trends at the moment.");
            }
        } catch (err) {
            setError("An error occurred while fetching AI trends.");
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadTrends();
    }, [loadTrends]);

    return (
        <Section
            title="AI Trend Forecast"
            subtitle="What's next in AI? Our trend analyst AI predicts the next big waves."
            icon={<TrendingUpIcon className="h-8 w-8 text-primary-500" />}
        >
            {isLoading ? (
                <div className="flex justify-center items-center h-48">
                    <Spinner />
                </div>
            ) : error ? (
                <p className="text-red-500 text-center">{error}</p>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 animate-fade-in">
                    {trends.map((trend, index) => (
                        <TrendCard key={index} trend={trend} />
                    ))}
                </div>
            )}
        </Section>
    );
};

export default TrendForecaster;