import React from 'react';
import { type Ad } from '../../types';

interface AdComponentProps {
    ad: Ad;
}

const AdComponent: React.FC<AdComponentProps> = ({ ad }) => (
    <div className="h-full">
        <a href={ad.ctaUrl} target="_blank" rel="noopener noreferrer sponsored" 
           className="block bg-white dark:bg-gray-800 rounded-lg shadow-md hover:shadow-xl transition-all duration-300 group animate-slide-up border-2 border-dashed border-gray-300 dark:border-gray-600 p-4 flex flex-col justify-between h-full">
            <div>
                <div className="flex justify-between items-center mb-2">
                    <span className="text-xs font-bold text-gray-500 dark:text-gray-400">{ad.company}</span>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-gray-200 text-gray-700 dark:bg-gray-700 dark:text-gray-300">Ad</span>
                </div>
                <img src={ad.imageUrl} alt={ad.headline} className="w-full h-32 object-cover rounded-md mb-3" />
                <h3 className="font-bold text-gray-900 dark:text-white group-hover:text-primary-500 transition-colors">{ad.headline}</h3>
                <p className="mt-1 text-sm text-gray-600 dark:text-gray-300 flex-grow">{ad.description}</p>
            </div>
            <button className="mt-4 w-full text-center bg-primary-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-primary-600 transition-colors">
                {ad.ctaText}
            </button>
        </a>
    </div>
);

export default AdComponent;
