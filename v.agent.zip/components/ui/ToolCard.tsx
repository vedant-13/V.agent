import React from 'react';
import { type Tool, type RadarTool } from '../../types';
import Tag from './Tag';
import { PlusIcon, CheckIcon } from './icons';

interface ToolCardProps {
  tool: Tool | RadarTool;
  onSelectForCompare?: (toolName: string) => void;
  isSelectedForCompare?: boolean;
}

const ToolCard: React.FC<ToolCardProps> = ({ tool, onSelectForCompare, isSelectedForCompare }) => {
  
  const handleSelectClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    onSelectForCompare?.(tool.name);
  }

  const isRadarTool = 'status' in tool;

  return (
    <div className={`relative rounded-lg shadow-md hover:shadow-xl transition-all duration-300 animate-slide-up border-2 flex flex-col ${isSelectedForCompare ? 'border-primary-500 scale-105' : 'border-transparent'}`}>
      <a 
        href={tool.url}
        target="_blank"
        rel="noopener noreferrer"
        className="block bg-white dark:bg-gray-800 p-6 group h-full flex flex-col flex-grow rounded-lg"
      >
        <div className="flex flex-col h-full">
          {isRadarTool && (
              <div className="absolute top-0 right-0 -mt-2 -mr-2">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-yellow-300 text-yellow-900">{tool.status}</span>
              </div>
          )}
          <div className="flex items-start justify-between">
            <h3 className="text-lg font-bold text-gray-900 dark:text-white group-hover:text-primary-500 transition-colors pr-8">
              {tool.name}
            </h3>
            <span className="text-2xl ml-4">{tool.icon}</span>
          </div>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-300 flex-grow">
            {tool.description}
          </p>
          <div className="mt-4 flex items-center justify-between">
            <Tag label={tool.category} />
            {tool.pricing && (
              <span className="text-xs font-semibold px-2 py-1 rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">{tool.pricing}</span>
            )}
          </div>
        </div>
      </a>
      {onSelectForCompare && (
          <button onClick={handleSelectClick} className={`absolute top-2 left-2 p-1.5 rounded-full transition-all duration-200 ${isSelectedForCompare ? 'bg-primary-500 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 opacity-0 group-hover:opacity-100'}`} aria-label={isSelectedForCompare ? 'Deselect for compare' : 'Select for compare'}>
              {isSelectedForCompare ? <CheckIcon className="h-4 w-4" /> : <PlusIcon className="h-4 w-4" />}
          </button>
      )}
    </div>
  );
};

export default ToolCard;
