
import React, { useEffect, useRef } from 'react';
import { type NewsArticle } from '../../types';
import { PlayIcon, StopCircleIcon } from './icons';

declare var anime: any;

interface NewsCardProps {
  article: NewsArticle;
  onPlaySummary: (summary: string, headline: string) => void;
  isCardSpeaking: boolean;
}

const WaveformVisual: React.FC = () => (
    <div className="flex items-center justify-center gap-0.5 h-4">
        <div className="w-1 h-1 bg-primary-400 rounded-full animate-[waveform_1s_ease-in_out_infinite_0s]"/>
        <div className="w-1 h-1 bg-primary-400 rounded-full animate-[waveform_1s_ease_in_out_infinite_0.2s]"/>
        <div className="w-1 h-1 bg-primary-400 rounded-full animate-[waveform_1s_ease_in_out_infinite_0.4s]"/>
        <style>{`
            @keyframes waveform {
                0%, 100% { transform: scaleY(0.5); }
                50% { transform: scaleY(1.5); }
            }
        `}</style>
    </div>
);

const NewsCard: React.FC<NewsCardProps> = ({ article, onPlaySummary, isCardSpeaking }) => {
  const { url, headline, summary, source, date, icon } = article;
  const headlineRef = useRef(null);

  useEffect(() => {
    if (headlineRef.current) {
      // @ts-ignore
      const letters = headlineRef.current.textContent.split('');
      // @ts-ignore
      headlineRef.current.innerHTML = letters.map(l => `<span class="letter">${l === ' ' ? '&nbsp;' : l}</span>`).join('');
      
      anime.timeline({loop: false})
        .add({
          targets: '.letter',
          translateY: [100,0],
          translateZ: 0,
          opacity: [0,1],
          easing: "easeOutExpo",
          duration: 1400,
          delay: (el: any, i: number) => 300 + 30 * i
        });
    }
  }, []);

  const handlePlayClick = (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      onPlaySummary(summary, headline);
  }

  return (
    <div className="bg-white dark:bg-black/20 dark:backdrop-blur-lg rounded-xl border border-gray-200 dark:border-white/10 shadow-lg text-gray-900 dark:text-white flex flex-col h-full group transition-all duration-300 hover:border-primary-500 hover:scale-105 animate-slide-up">
      <div className="p-5 flex-grow flex flex-col">
        <div className="flex justify-between items-start mb-3">
            <div className="text-xs uppercase font-semibold text-gray-500 dark:text-gray-400">{source} &bull; {date}</div>
            <div className="text-2xl -mt-1">{icon}</div>
        </div>
        
        <h3 className="text-xl font-bold mb-3 h-20 overflow-hidden">
           <span ref={headlineRef} className="headline">{headline}</span>
        </h3>
        
        <p className="text-sm text-gray-600 dark:text-gray-300 mb-4 flex-grow line-clamp-4">
          {summary}
        </p>
      </div>

      <div className="p-5 border-t border-gray-200 dark:border-white/10 flex items-center justify-between mt-auto">
         <a 
            href={url}
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-2 text-sm font-bold bg-primary-100 text-primary-700 border border-primary-200 rounded-full hover:bg-primary-200 transition-colors animate-glow dark:bg-primary-500/20 dark:text-primary-300 dark:border-primary-500/30 dark:hover:bg-primary-500/40"
        >
            Read Full Article
        </a>
        <button onClick={handlePlayClick} className="w-10 h-10 flex items-center justify-center bg-gray-100 dark:bg-white/10 rounded-full hover:bg-gray-200 dark:hover:bg-white/20 transition-colors">
            {isCardSpeaking ? <WaveformVisual /> : <PlayIcon className="h-5 w-5 text-primary-400"/>}
        </button>
      </div>
    </div>
  );
};

export default NewsCard;