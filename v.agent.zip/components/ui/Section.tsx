import React from 'react';

interface SectionProps {
  title: string;
  subtitle: string;
  children?: React.ReactNode;
  headerAction?: React.ReactNode;
  icon?: React.ReactNode;
}

const Section: React.FC<SectionProps> = ({ title, subtitle, children, headerAction, icon }) => {
  return (
    <section className="py-8">
      <div className={children ? "mb-6" : ""}>
         <div className="flex justify-between items-center">
            <div className="flex items-center gap-3">
              {icon}
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{title}</h2>
            </div>
            {headerAction}
         </div>
        <p className="mt-2 text-md text-gray-500 dark:text-gray-400">{subtitle}</p>
      </div>
      {children && <div>{children}</div>}
    </section>
  );
};

export default Section;