
import React from 'react';

interface TagProps {
  label: string;
  isActive?: boolean;
  onClick?: () => void;
}

const Tag: React.FC<TagProps> = ({ label, isActive = false, onClick }) => {
  const baseClasses = 'px-3 py-1 text-xs font-medium rounded-full transition-colors duration-200';
  const activeClasses = 'bg-primary-500 text-white';
  const inactiveClasses = 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-200';
  const clickableClasses = onClick ? 'cursor-pointer hover:bg-primary-400 dark:hover:bg-primary-600' : '';

  return (
    <span
      className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses} ${onClick ? clickableClasses : ''}`}
      onClick={onClick}
    >
      {label}
    </span>
  );
};

export default Tag;
