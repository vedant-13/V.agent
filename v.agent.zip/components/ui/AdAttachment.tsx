import React from 'react';
import { type Ad } from '../../types';
import { ArrowRightIcon } from './icons';

interface AdAttachmentProps {
    ad: Ad;
}

const AdAttachment: React.FC<AdAttachmentProps> = ({ ad }) => {
    return (
        <a href={ad.ctaUrl} target="_blank" rel="noopener noreferrer sponsored" className="block p-3 bg-gray-50 dark:bg-gray-800/70 border-t border-gray-200 dark:border-gray-700 rounded-b-lg group">
            <div className="flex justify-between items-center text-xs mb-1">
                <span className="font-bold text-gray-600 dark:text-gray-400">{ad.company}</span>
                <span className="px-1.5 py-0.5 bg-gray-200 dark:bg-gray-700 rounded-full font-semibold text-gray-700 dark:text-gray-300">Sponsored</span>
            </div>
            <div className="text-sm text-primary-600 dark:text-primary-400 group-hover:underline font-semibold flex items-center justify-between">
                <span>{ad.headline}</span>
                <ArrowRightIcon className="h-4 w-4 transition-transform group-hover:translate-x-1" />
            </div>
        </a>
    );
};

export default AdAttachment;
