
import React, { useEffect } from 'react';

declare global {
    interface Window {
        adsbygoogle?: any[];
    }
}

const AdSenseBanner: React.FC = () => {
    useEffect(() => {
        try {
            // This is safe to run on every render, as AdSense script checks if an ad has already been loaded into the container.
            (window.adsbygoogle = window.adsbygoogle || []).push({});
        } catch (e) {
            console.error("AdSense execution error:", e);
        }
    }, []);

    // NOTE: This uses Google's official test ad client ID.
    // For a production app, you would replace this with your own publisher ID.
    const adClient = "ca-pub-3940256099942970"; 
    
    // NOTE: This is a placeholder for your ad slot ID.
    // You would get this from your AdSense account. This is a test ID for a responsive ad unit.
    const adSlot = "5135763105";

    return (
        <div className="fixed bottom-0 left-0 w-full bg-white dark:bg-gray-900 h-[70px] flex items-center justify-center border-t border-gray-200 dark:border-gray-700 z-30">
            <div className="w-full h-full max-w-screen-lg px-2">
                <ins className="adsbygoogle"
                     style={{ display: 'block', width: '100%', height: '100%' }}
                     data-ad-client={adClient}
                     data-ad-slot={adSlot}
                     data-ad-format="auto"
                     data-ad-full-width-responsive="true"></ins>
            </div>
            <div className="absolute top-0 right-0 text-xs bg-gray-200 dark:bg-gray-700 px-1 text-gray-500 dark:text-gray-400 opacity-50">Test Ad</div>
        </div>
    );
};

export default AdSenseBanner;
