import React from 'react';
import { GoogleMeetIcon, ZoomIcon } from './icons';

interface ScheduleItemProps {
  title: string;
  time: string;
  platform: 'Google Meet' | 'Zoom Meeting';
  attendees: string[];
}

const ScheduleItem: React.FC<ScheduleItemProps> = ({ title, time, platform, attendees }) => {
  const PlatformIcon = platform === 'Google Meet' ? GoogleMeetIcon : ZoomIcon;

  return (
    <div className="border-l-4 border-primary-500 pl-4 py-2">
      <h4 className="font-bold text-gray-800 dark:text-white">{title}</h4>
      <p className="text-sm text-gray-500 dark:text-gray-400">20 May, 2025 • {time}</p>
      <div className="flex items-center justify-between mt-2">
        <div className="flex items-center gap-2 text-sm text-blue-600 dark:text-blue-400 font-semibold">
          <PlatformIcon className="h-5 w-5" />
          <span>{platform}</span>
        </div>
        <div className="flex -space-x-2">
          {attendees.map((src, index) => (
            <img key={index} src={src} alt={`attendee ${index+1}`} className="h-6 w-6 rounded-full border-2 border-white dark:border-dark_ui-card" />
          ))}
        </div>
      </div>
    </div>
  );
};

export default ScheduleItem;
