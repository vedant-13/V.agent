import React from 'react';
import { type SearchMessage, type Tool, type NewsArticle } from '../../types';
import ToolCard from './ToolCard';
import NewsCard from './NewsCard';
import { LinkIcon } from './icons';

interface SearchMessageProps {
  message: SearchMessage;
  onAction: (label: string, action: string, payload?: any) => void;
}

const SearchMessageComponent: React.FC<SearchMessageProps> = ({ message, onAction }) => {
  const { role, text, options, results, resultType, sources } = message;

  return (
    <div className={`flex flex-col gap-2 ${role === 'user' ? 'items-end' : 'items-start'}`}>
      <div
        className={`max-w-lg rounded-lg px-4 py-3 ${
          role === 'user'
            ? 'bg-primary-500 text-white'
            : 'bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-gray-100'
        }`}
      >
        {text && <p className="whitespace-pre-wrap">{text}</p>}
      </div>

      {options && options.length > 0 && (
        <div className="flex flex-wrap gap-2 max-w-lg">
          {options.map((opt, i) => (
            <button
              key={i}
              onClick={() => onAction(opt.label, opt.action, opt.payload)}
              className="px-3 py-1.5 text-sm font-medium rounded-full bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-600 text-primary-600 dark:text-primary-400 hover:bg-primary-50 dark:hover:bg-gray-600 transition-colors"
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}

      {results && resultType === 'tools' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full mt-2">
            {(results as Tool[]).map((tool, i) => <ToolCard key={`${tool.name}-${i}`} tool={tool} />)}
        </div>
      )}
      
      {sources && sources.length > 0 && (
        <div className="max-w-lg w-full mt-2">
            <h4 className="text-sm font-semibold text-gray-600 dark:text-gray-400 mb-2">Sources:</h4>
            <div className="space-y-2">
                {sources.map((source, i) => (
                    <a 
                        key={i} 
                        href={source.uri} 
                        target="_blank" 
                        rel="noopener noreferrer" 
                        className="flex items-start space-x-2 text-xs text-blue-500 hover:underline bg-gray-100 dark:bg-gray-700 p-2 rounded-md"
                    >
                       <LinkIcon className="h-4 w-4 shrink-0 mt-0.5" />
                       <span className="truncate">{source.title || source.uri}</span>
                    </a>
                ))}
            </div>
        </div>
      )}
    </div>
  );
};

export default SearchMessageComponent;