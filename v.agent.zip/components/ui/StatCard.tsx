import React from 'react';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string;
  change: number;
  changeType: 'increase' | 'decrease';
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, change, changeType }) => {
  const isIncrease = changeType === 'increase';
  const changeColor = isIncrease ? 'text-green-500 bg-green-100 dark:bg-green-500/10 dark:text-green-400' : 'text-red-500 bg-red-100 dark:bg-red-500/10 dark:text-red-400';
  
  return (
    <div className="bg-white dark:bg-dark_ui-card p-5 rounded-lg shadow-sm border border-ui-border dark:border-dark_ui-border">
      <div className="flex items-center justify-between">
        <div className="p-2 bg-blue-100 dark:bg-primary-500/10 rounded-lg">
          {icon}
        </div>
        <div className={`text-xs font-bold px-2 py-1 rounded-full ${changeColor}`}>
          {isIncrease ? '▲' : '▼'} {change}%
        </div>
      </div>
      <div className="mt-4">
        <p className="text-gray-500 dark:text-gray-400 text-sm">{title}</p>
        <p className="text-3xl font-bold text-gray-800 dark:text-white">{value}</p>
      </div>
      <p className="text-xs text-gray-400 mt-2">Update: 8 May 2025</p>
    </div>
  );
};

export default StatCard;
