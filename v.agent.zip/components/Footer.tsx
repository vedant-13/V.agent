
import React from 'react';
import { type ActiveView } from '../types';

interface FooterProps {
  setActiveView: (view: ActiveView) => void;
}

const Footer: React.FC<FooterProps> = ({ setActiveView }) => {
  const navLinks: { label: string, view: ActiveView }[] = [
    { label: 'About', view: 'about' },
    { label: 'Contact Us', view: 'contact' },
    { label: 'Privacy Policy', view: 'privacy' },
    { label: 'Terms of Use', view: 'terms' },
  ];

  return (
    <footer className="bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-6">
            <p className="text-sm text-center md:text-left text-gray-500 dark:text-gray-400">
                &copy; {new Date().getFullYear()} V.agent. All rights reserved.
            </p>
            <nav className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm">
                {navLinks.map(link => (
                    <button 
                        key={link.view} 
                        onClick={() => setActiveView(link.view)}
                        className="text-gray-500 dark:text-gray-400 hover:text-primary-500 dark:hover:text-primary-400 transition-colors"
                        aria-label={`Go to ${link.label} page`}
                    >
                        {link.label}
                    </button>
                ))}
            </nav>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
