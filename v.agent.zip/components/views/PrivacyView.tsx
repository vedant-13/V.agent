
import React from 'react';

const PrivacyView: React.FC = () => {
  const lastUpdated = 'July 26, 2024';

  return (
    <div className="animate-fade-in max-w-4xl mx-auto py-8 bg-white dark:bg-gray-800/50 p-6 sm:p-10 rounded-lg shadow-md">
      <h1 className="text-3xl sm:text-4xl font-extrabold text-gray-900 dark:text-white mb-4">Privacy Policy</h1>
      <p className="text-sm text-gray-500 dark:text-gray-400 mb-8">Last Updated: {lastUpdated}</p>

      <div className="prose prose-lg dark:prose-invert max-w-none text-gray-700 dark:text-gray-300 space-y-6">
        <p>
          Welcome to V.agent ("we," "our," or "us"). We are committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our application.
        </p>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">1. Information We Collect</h2>
        <p>
          We may collect information about you in a variety of ways. The information we may collect via the application includes:
        </p>
        <ul>
          <li>
            <strong>Personal Data:</strong> We do not directly collect personally identifiable information such as your name, shipping address, or email address. Any text you input into our features is sent to the Google Gemini API for processing but is not stored by us.
          </li>
          <li>
            <strong>Derivative Data:</strong> Our application may automatically collect information your browser sends when you are using the app, such as your browser type, browser version, and your device's operating system.
          </li>
          <li>
            <strong>Local Storage Data:</strong> We use your browser's local storage to save your application preferences, such as your preferred theme (dark or light mode). This data is stored only on your device and is not transmitted to our servers.
          </li>
        </ul>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">2. Use of Your Information</h2>
        <p>
          Having accurate information permits us to provide you with a smooth, efficient, and customized experience. Specifically, we may use information collected about you via the Application to:
        </p>
        <ul>
            <li>Enable core application functionality.</li>
            <li>Respond to your requests and provide user support.</li>
            <li>Monitor and analyze usage and trends to improve your experience with the Application.</li>
            <li>Maintain the security and operation of our Application.</li>
        </ul>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">3. Third-Party Services</h2>
        <p>
          This application relies on the Google Gemini API to provide its core functionality. When you use features that require AI processing (such as search, summarization, or chat), the text or queries you provide are sent to Google's servers. We recommend you review Google's Privacy Policy to understand how they handle your data. We are not responsible for the policies or practices of third parties.
        </p>
         <p>
            This application may also use Google AdSense to display advertisements. Google may use cookies to serve ads based on a user's prior visits to this website or other websites. You can opt out of personalized advertising by visiting Ads Settings in your Google account.
        </p>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">4. Security of Your Information</h2>
        <p>
          We use administrative, technical, and physical security measures to help protect your personal information. While we have taken reasonable steps to secure the information you provide to us, please be aware that despite our efforts, no security measures are perfect or impenetrable, and no method of data transmission can be guaranteed against any interception or other type of misuse.
        </p>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">5. Changes to This Privacy Policy</h2>
        <p>
          We may update this Privacy Policy from time to time in order to reflect, for example, changes to our practices or for other operational, legal, or regulatory reasons. We will notify you of any changes by posting the new Privacy Policy on this page.
        </p>

        <h2 className="!mt-10 !mb-4 text-2xl font-bold text-gray-900 dark:text-white">6. Contact Us</h2>
        <p>
          If you have questions or comments about this Privacy Policy, please contact us through the "Contact Us" page.
        </p>
      </div>
    </div>
  );
};

export default PrivacyView;
