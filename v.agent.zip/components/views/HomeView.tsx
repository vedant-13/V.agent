import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { type Tool, type NewsArticle, type ActiveView, type Ad } from '../../types';
import { fetchData } from '../../services/geminiService';
import ToolCard from '../ui/ToolCard';
import NewsCard from '../ui/NewsCard';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import { ArrowRightIcon, RadarIcon } from '../ui/icons';
import UseCaseRecommender from '../features/UseCaseRecommender';
import TrendForecaster from '../features/TrendForecaster';
import { mockAds } from '../../data/mockAds';
import AdComponent from '../ui/AdComponent';

const SkeletonCard: React.FC = () => (
  <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md animate-pulse">
    <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-3/4 mb-2"></div>
    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-full mb-4"></div>
    <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2"></div>
  </div>
);

interface HomeViewProps {
  setActiveView: (view: ActiveView) => void;
}

// --- SPEECH SYNTHESIS HOOK ---
const useSpeechSynthesis = () => {
    const [isSpeaking, setIsSpeaking] = useState(false);
    const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

    const speak = useCallback((text: string) => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        if(isSpeaking) window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = (e) => {
            console.error("Speech synthesis error", e);
            setIsSpeaking(false);
        }
        utteranceRef.current = utterance;
        window.speechSynthesis.speak(utterance);
    }, [isSpeaking]);

    const cancel = useCallback(() => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
    }, []);

    return { isSpeaking, speak, cancel };
};

const HomeView: React.FC<HomeViewProps> = ({ setActiveView }) => {
  const [topTools, setTopTools] = useState<Tool[]>([]);
  const [trendingNews, setTrendingNews] = useState<NewsArticle[]>([]);
  const [loadingTools, setLoadingTools] = useState(true);
  const [loadingNews, setLoadingNews] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [speakingArticle, setSpeakingArticle] = useState<string | null>(null);

  const { isSpeaking, speak, cancel } = useSpeechSynthesis();

  const loadContent = useCallback(async () => {
    try {
      setLoadingTools(true);
      setLoadingNews(true);
      const [toolsData, newsData] = await Promise.all([
        fetchData<Tool>('weeklyTop'),
        fetchData<NewsArticle>('trendingNews')
      ]);
      setTopTools(toolsData);
      setTrendingNews(newsData);
    } catch (err) {
      setError('Failed to load content. The AI might be taking a nap.');
      console.error(err);
    } finally {
      setLoadingTools(false);
      setLoadingNews(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  
  const itemsWithAds = useMemo(() => {
    if (!topTools || topTools.length === 0) return [];
    const items: (Tool | Ad)[] = [...topTools];
    if (items.length > 3 && mockAds.length > 0) {
      items.splice(3, 0, mockAds[0]);
    }
    return items;
  }, [topTools]);


  const playSummary = (text: string, headline: string) => {
      if (isSpeaking && speakingArticle === headline) {
          cancel();
          setSpeakingArticle(null);
      } else {
          speak(text);
          setSpeakingArticle(headline);
      }
  };

  useEffect(() => {
      if(!isSpeaking) {
          setSpeakingArticle(null);
      }
  }, [isSpeaking]);

  if (error) {
    return <div className="text-center text-red-500 py-20">{error}</div>;
  }

  return (
    <div className="space-y-16 animate-fade-in">
       <div className="text-center py-12">
        <h1 className="text-4xl md:text-6xl font-extrabold tracking-tight text-gray-900 dark:text-white">
          Discover What's <span className="text-primary-500">Next in AI</span>
        </h1>
        <p className="mt-4 text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Your intelligent gateway to the latest AI tools, news, and breakthroughs, curated and summarized by AI.
        </p>
      </div>

      <div
        className="relative bg-gradient-to-r from-primary-500 to-blue-600 dark:from-primary-600 dark:to-blue-700 text-white p-6 rounded-lg shadow-lg overflow-hidden cursor-pointer group hover:shadow-2xl transition-shadow duration-300"
        onClick={() => setActiveView('radar')}
      >
        <div className="absolute -right-4 -bottom-4">
          <RadarIcon className="h-32 w-32 text-white/10 group-hover:text-white/20 transition-colors duration-300 transform group-hover:rotate-12" />
        </div>
        <div className="relative z-10">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <span className="bg-white/20 p-2 rounded-lg"><RadarIcon className="h-6 w-6"/></span>
            New Feature: Live Tool Launch Radar
          </h2>
          <p className="mt-2 text-blue-100">See AI tools the moment they launch or start trending. Your real-time feed from the cutting edge of AI.</p>
          <div className="mt-4 font-semibold flex items-center gap-2 group-hover:underline">
            <span>Explore the Radar</span>
            <ArrowRightIcon className="h-5 w-5 transition-transform duration-300 group-hover:translate-x-1" />
          </div>
        </div>
      </div>

      <UseCaseRecommender />

      <TrendForecaster />

      <Section 
        title="🏆 Weekly Top Tools" 
        subtitle="The most popular AI tools of the week, picked by our AI agent."
        headerAction={
          <button onClick={() => setActiveView('tools')} className="flex items-center space-x-2 text-sm font-medium text-primary-500 hover:text-primary-600 dark:hover:text-primary-400">
            <span>View All Tools</span>
            <ArrowRightIcon className="h-4 w-4" />
          </button>
        }
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {loadingTools
            ? Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
            : itemsWithAds.map((item, index) => {
                if ('company' in item) { // Type guard for Ad
                  return <AdComponent key={item.id} ad={item} />;
                }
                return <ToolCard key={`${item.name}-${index}`} tool={item} />;
              })}
        </div>
      </Section>
      
      <Section 
        title="📰 Trending AI News" 
        subtitle="The latest headlines and summaries from the world of AI."
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {loadingNews
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : trendingNews.map((article, index) => (
                <NewsCard 
                  key={`${article.headline}-${index}`} 
                  article={article} 
                  onPlaySummary={playSummary}
                  isCardSpeaking={speakingArticle === article.headline}
                />
              ))}
        </div>
      </Section>
    </div>
  );
};

export default HomeView;