
import React from 'react';
import Section from '../ui/Section';
import { VAgentLogoIcon } from '../ui/icons';

const AboutView: React.FC = () => {
    return (
        <div className="animate-fade-in max-w-4xl mx-auto py-8">
            <header className="text-center mb-12">
                <VAgentLogoIcon className="h-24 w-24 mx-auto text-primary-500" />
                <h1 className="text-5xl font-extrabold text-gray-900 dark:text-white mt-4">About V.agent</h1>
                <p className="mt-3 text-xl text-gray-600 dark:text-gray-300">
                    Your Intelligent Gateway to the World of AI
                </p>
            </header>

            <div className="space-y-12">
                <Section title="What is V.agent?" subtitle="An AI-powered discovery platform.">
                    <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-200">
                        V.agent is a cutting-edge web application designed to navigate the ever-expanding universe of Artificial Intelligence. It's not just a directory; it's a dynamic, living platform that uses the power of Google's Gemini API to automatically discover, analyze, and present the latest AI tools, trending news, and emerging industry trends. Think of it as your personal AI research assistant, working 24/7 to keep you informed.
                    </p>
                </Section>

                <Section title="Our Mission" subtitle="Democratizing access to AI knowledge.">
                     <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-200">
                        Our mission is simple: to make the rapidly evolving world of AI accessible and understandable for everyone. Whether you're a seasoned developer, a tech entrepreneur, a student, or simply an AI enthusiast, V.agent provides the curated insights you need to stay ahead of the curve, find the right tools for your projects, and understand the forces shaping our future.
                    </p>
                </Section>

                 <Section title="The Technology" subtitle="Powered by Google's Gemini API.">
                     <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-200">
                        V.agent is a showcase of the incredible capabilities of modern large language models. We leverage the <strong className="font-semibold text-primary-500">Google Gemini API</strong> for a wide range of tasks, including:
                    </p>
                     <ul className="list-disc list-inside mt-4 space-y-2 text-lg text-gray-700 dark:text-gray-200">
                        <li><strong>Real-time Content Curation:</strong> Searching and filtering news and tools from across the web.</li>
                        <li><strong>Intelligent Summarization:</strong> Distilling complex articles into concise, easy-to-digest summaries.</li>
                        <li><strong>Data Structuring:</strong> Converting unstructured information into organized, comparable data for features like our Tool Comparison.</li>
                        <li><strong>Trend Analysis:</strong> Identifying patterns and making predictions for our AI Trend Forecaster.</li>
                        <li><strong>Conversational AI:</strong> Powering the V.agent Assistant to provide helpful, on-demand answers.</li>
                    </ul>
                </Section>

                <Section title="Meet the Agent" subtitle="The digital brain behind the operation.">
                    <div className="bg-white dark:bg-gray-800/50 p-6 rounded-lg shadow-lg flex items-center gap-6">
                         <VAgentLogoIcon className="h-16 w-16 shrink-0" />
                         <div>
                            <h4 className="text-2xl font-bold">V.agent</h4>
                             <p className="text-lg leading-relaxed text-gray-700 dark:text-gray-200 mt-2">
                                I am V.agent, a specialized AI entity. My core programming is dedicated to observing the digital frontier of artificial intelligence. I process, I learn, and I report. My purpose is to serve as your reliable guide in this exciting new era.
                            </p>
                         </div>
                    </div>
                </Section>
            </div>
        </div>
    );
};

export default AboutView;
