import React, { useState, useEffect, useCallback } from 'react';
import { type Tool } from '../../types';
import { fetchAgentTools } from '../../services/geminiService';
import { RADAR_CATEGORIES } from '../../constants';
import ToolCard from '../ui/ToolCard';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import Tag from '../ui/Tag';
import { BrainCircuitIcon, CompareIcon } from '../ui/icons';

interface DiscoverViewProps {
  onCompare: (tools: Tool[]) => void;
}

const AGENT_CATEGORIES = RADAR_CATEGORIES["🤖 Agents & Automation"];

const DiscoverView: React.FC<DiscoverViewProps> = ({ onCompare }) => {
  const [tools, setTools] = useState<Tool[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);

  const loadAgents = useCallback(async () => {
    setLoading(true);
    setError(null);
    setTools([]);
    try {
      const data = await fetchAgentTools(selectedCategory);
      setTools(data);
    } catch (err) {
      setError('Failed to load AI Agent tools. Please try again later.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [selectedCategory]);

  useEffect(() => {
    loadAgents();
  }, [loadAgents]);

  const handleSelectForCompare = (toolName: string) => {
    setSelectedForCompare(prev => {
      if (prev.includes(toolName)) {
        return prev.filter(name => name !== toolName);
      }
      if (prev.length < 3) {
        return [...prev, toolName];
      }
      return prev;
    });
  };

  const handleCompareClick = () => {
    const toolsToCompare = tools.filter(tool => selectedForCompare.includes(tool.name));
    onCompare(toolsToCompare);
    setSelectedForCompare([]);
  }

  return (
    <div className="animate-fade-in p-6 md:p-8">
      <Section 
        title="AI Agent Toolkit" 
        subtitle="Discover autonomous and specialized agents to automate your tasks and research."
        icon={<BrainCircuitIcon className="h-8 w-8 text-primary-500" />}
      >
        <div className="bg-white/50 dark:bg-dark_ui-card/50 p-4 sm:p-6 rounded-lg shadow-inner border border-ui-border dark:border-dark_ui-border mb-8">
            <div className="flex flex-wrap items-center gap-2">
                <Tag
                    label="All Agents"
                    isActive={selectedCategory === 'All'}
                    onClick={() => setSelectedCategory('All')}
                />
                {AGENT_CATEGORIES.map(category => (
                    <Tag
                        key={category}
                        label={category}
                        isActive={selectedCategory === category}
                        onClick={() => setSelectedCategory(category)}
                    />
                ))}
            </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Spinner />
          </div>
        ) : error ? (
          <div className="text-center text-red-500 py-20">{error}</div>
        ) : (
          <>
            <h4 className="text-lg font-semibold mb-6 text-center">
              Showing results for: <span className="text-primary-500 font-bold">{selectedCategory}</span>
            </h4>
            {tools.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {tools.map((tool, index) => (
                        <ToolCard 
                            key={`${tool.name}-${index}`} 
                            tool={tool}
                            onSelectForCompare={handleSelectForCompare}
                            isSelectedForCompare={selectedForCompare.includes(tool.name)}
                        />
                      ))}
                </div>
            ) : (
                <div className="text-center text-gray-500 dark:text-gray-400 py-20">
                    <p className="text-lg">No agents found for "{selectedCategory}".</p>
                    <p>Our AI is always deploying new agents. Try another category or check back soon!</p>
                </div>
            )}
          </>
        )}
      </Section>

       {selectedForCompare.length >= 2 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={handleCompareClick}
            className="flex items-center gap-3 bg-primary-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-primary-700 transition-all duration-300 animate-slide-up"
          >
            <CompareIcon className="h-6 w-6" />
            Compare Agents ({selectedForCompare.length})
          </button>
        </div>
      )}
    </div>
  );
};

export default DiscoverView;