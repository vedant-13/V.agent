
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { type NewsArticle } from '../../types';
import { searchAINews } from '../../services/geminiService';
import { REGIONS, NEWS_CATEGORIES, NEWS_FILTERS } from '../../constants';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import NewsCard from '../ui/NewsCard';
import { SearchIcon, MicIcon, StopCircleIcon } from '../ui/icons';

declare var anime: any;

declare global {
    interface Window {
        SpeechRecognition: any;
        webkitSpeechRecognition: any;
    }
}

// --- SPEECH RECOGNITION HOOK ---
const useSpeechRecognition = (options: { onResult: (transcript: string) => void }) => {
  const [isListening, setIsListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn("Speech recognition not supported in this browser.");
      return;
    }
    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.lang = 'en-US';
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error);
        setIsListening(false);
    };
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      options.onResult(transcript);
    };
    recognitionRef.current = recognition;
  }, [options.onResult]);

  const startListening = () => {
    if (recognitionRef.current && !isListening) {
      try {
        recognitionRef.current.start();
      } catch (err) {
        console.error("Could not start recognition:", err);
      }
    }
  };

  return { isListening, startListening };
};

// --- SPEECH SYNTHESIS HOOK ---
const useSpeechSynthesis = () => {
    const [isSpeaking, setIsSpeaking] = useState(false);
    const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

    const speak = useCallback((text: string) => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        if(isSpeaking) window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = (e) => {
            console.error("Speech synthesis error", e);
            setIsSpeaking(false);
        }
        utteranceRef.current = utterance;
        window.speechSynthesis.speak(utterance);
    }, [isSpeaking]);

    const cancel = useCallback(() => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
    }, []);

    return { isSpeaking, speak, cancel };
};


const NewsView: React.FC = () => {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [filters, setFilters] = useState({
    category: 'AI',
    filterType: 'Trending',
    region: 'Worldwide',
  });
  const [query, setQuery] = useState('Latest news in AI');
  const [speakingArticle, setSpeakingArticle] = useState<string | null>(null);

  const { isListening, startListening } = useSpeechRecognition({
      onResult: (transcript) => {
          setQuery(transcript);
          handleSearch(transcript);
      }
  });
  const { isSpeaking, speak, cancel } = useSpeechSynthesis();

  const micRef = useRef(null);

  useEffect(() => {
      if (!micRef.current) return;
      anime({
          targets: micRef.current,
          scale: isListening ? [1, 1.2, 1] : 1,
          loop: isListening,
          duration: 1200,
          easing: 'easeInOutSine'
      });
  }, [isListening]);


  const handleSearch = useCallback(async (currentQuery: string) => {
    if(!currentQuery) return;
    setLoading(true);
    setError(null);
    setArticles([]);
    setSummary('');
    if (isSpeaking) cancel();

    try {
      const { articles: fetchedArticles, text } = await searchAINews({ 
        query: currentQuery, 
        ...filters 
      });
      setArticles(fetchedArticles);
      setSummary(text);
      if (text) {
          speak(text);
      }
    } catch (err) {
      setError('Failed to load AI news. Please try again later.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [filters, isSpeaking, cancel, speak]);

  useEffect(() => {
    handleSearch('Latest news in AI');
  }, []); // Run on initial mount

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSearch(query);
  }

  const playSummary = (text: string, headline: string) => {
      if (isSpeaking && speakingArticle === headline) {
          cancel();
          setSpeakingArticle(null);
      } else {
          speak(text);
          setSpeakingArticle(headline);
      }
  };

  useEffect(() => {
      if(!isSpeaking) {
          setSpeakingArticle(null);
      }
  }, [isSpeaking]);

  return (
    <div className="animate-fade-in space-y-8 dark text-white min-h-full p-4 rounded-xl bg-gray-900/50">
        <div className="bg-black/20 backdrop-blur-md rounded-xl p-4 sm:p-6 border border-white/10 shadow-lg">
            <h1 className="text-3xl md:text-4xl font-bold text-center mb-2">
                <span className="text-primary-400">AI</span> News Radar
            </h1>
            <p className="text-center text-gray-300 mb-6">Your voice-activated gateway to global tech and AI news.</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="flex flex-col">
                    <label className="text-xs font-bold text-gray-400 mb-1">Category</label>
                    <select value={filters.category} onChange={e => setFilters(f => ({...f, category: e.target.value}))} className="bg-white/10 p-2 rounded-md border border-white/20 focus:outline-none focus:ring-2 focus:ring-primary-500">
                        {NEWS_CATEGORIES.map(c => <option key={c} value={c} className="bg-gray-800">{c}</option>)}
                    </select>
                </div>
                <div className="flex flex-col">
                    <label className="text-xs font-bold text-gray-400 mb-1">Filter</label>
                    <select value={filters.filterType} onChange={e => setFilters(f => ({...f, filterType: e.target.value}))} className="bg-white/10 p-2 rounded-md border border-white/20 focus:outline-none focus:ring-2 focus:ring-primary-500">
                        {NEWS_FILTERS.map(f => <option key={f} value={f} className="bg-gray-800">{f}</option>)}
                    </select>
                </div>
                <div className="flex flex-col">
                    <label className="text-xs font-bold text-gray-400 mb-1">Region</label>
                     <select value={filters.region} onChange={e => setFilters(f => ({...f, region: e.target.value}))} className="bg-white/10 p-2 rounded-md border border-white/20 focus:outline-none focus:ring-2 focus:ring-primary-500">
                        {REGIONS.map(r => <option key={r} value={r} className="bg-gray-800">{r}</option>)}
                    </select>
                </div>
            </div>
            
            <form onSubmit={handleFormSubmit} className="flex gap-2">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Ask about AI news..."
                    className="w-full p-3 text-lg bg-white/10 rounded-md border border-white/20 focus:outline-none focus:ring-2 focus:ring-primary-500"
                />
                <button type="button" onClick={startListening} ref={micRef} className="p-3 bg-primary-500 rounded-md hover:bg-primary-600 transition-colors disabled:opacity-50" disabled={isListening}>
                    <MicIcon className="h-6 w-6"/>
                </button>
                <button type="submit" className="p-3 bg-gray-600 rounded-md hover:bg-gray-700 transition-colors" disabled={loading}>
                   {loading ? <Spinner size="sm" /> : <SearchIcon className="h-6 w-6"/>}
                </button>
            </form>
        </div>
        
        <div className="space-y-6">
            {loading && <div className="flex justify-center p-10"><Spinner size="lg"/></div>}
            
            {error && <div className="text-center text-red-400 p-10 bg-black/20 rounded-xl">{error}</div>}

            {!loading && summary && (
                <div className="bg-black/20 backdrop-blur-md rounded-xl p-6 border border-white/10 shadow-lg flex items-start gap-4 animate-fade-in">
                    <div className="shrink-0 text-3xl">🤖</div>
                    <p className="flex-grow text-gray-200">{summary}</p>
                    {isSpeaking && (
                         <button onClick={cancel} className="p-2 bg-red-500/80 rounded-full hover:bg-red-500 transition-colors">
                            <StopCircleIcon className="h-6 w-6" />
                        </button>
                    )}
                </div>
            )}

            {!loading && articles.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {articles.map((article, index) => (
                        <NewsCard 
                            key={`${article.headline}-${index}`} 
                            article={article}
                            onPlaySummary={playSummary}
                            isCardSpeaking={speakingArticle === article.headline}
                        />
                    ))}
                </div>
            )}

            {!loading && !error && articles.length === 0 && (
                 <div className="text-center text-gray-400 p-10 bg-black/20 rounded-xl">
                    <p className="text-lg">No news found for this query.</p>
                    <p>Try being more specific, or use the voice search for a new perspective.</p>
                </div>
            )}
        </div>
    </div>
  );
};

export default NewsView;