import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { type Tool } from '../../types';
import { fetchData } from '../../services/geminiService';
import { TOOL_CATEGORIES } from '../../constants';
import ToolCard from '../ui/ToolCard';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import Tag from '../ui/Tag';
import { CompareIcon } from '../ui/icons';

interface ToolsViewProps {
  onCompare: (tools: Tool[]) => void;
}

const ToolsView: React.FC<ToolsViewProps> = ({ onCompare }) => {
  const [tools, setTools] = useState<Tool[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string | 'All'>('All');
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);

  const loadTools = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchData<Tool>('latestTools');
      setTools(data);
    } catch (err) {
      setError('Failed to load AI tools. Please try again later.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadTools();
  }, [loadTools]);

  const filteredTools = useMemo(() => {
    if (selectedCategory === 'All') {
      return tools;
    }
    return tools.filter(tool => tool.category === selectedCategory);
  }, [tools, selectedCategory]);

  const handleSelectForCompare = (toolName: string) => {
    setSelectedForCompare(prev => {
      if (prev.includes(toolName)) {
        return prev.filter(name => name !== toolName);
      }
      if (prev.length < 3) {
        return [...prev, toolName];
      }
      // Optional: show a toast notification that max 3 can be selected
      return prev;
    });
  };

  const handleCompareClick = () => {
    const toolsToCompare = tools.filter(tool => selectedForCompare.includes(tool.name));
    onCompare(toolsToCompare);
    setSelectedForCompare([]);
  }

  return (
    <div className="animate-fade-in p-6 md:p-8">
      <Section title="Discover AI Tools" subtitle="Explore the latest tools, filter by category to find what you need.">
        <div className="flex flex-wrap gap-2 mb-8">
          <Tag
            label="All"
            isActive={selectedCategory === 'All'}
            onClick={() => setSelectedCategory('All')}
          />
          {TOOL_CATEGORIES.map(category => (
            <Tag
              key={category}
              label={category}
              isActive={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
            />
          ))}
        </div>
        
        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Spinner />
          </div>
        ) : error ? (
          <div className="text-center text-red-500 py-20">{error}</div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTools.map((tool, index) => (
                <ToolCard 
                  key={`${tool.name}-${index}`} 
                  tool={tool}
                  onSelectForCompare={handleSelectForCompare}
                  isSelectedForCompare={selectedForCompare.includes(tool.name)}
                />
              ))}
          </div>
        )}
        
        {!loading && filteredTools.length === 0 && (
            <div className="text-center text-gray-500 dark:text-gray-400 py-20">
                <p className="text-lg">No tools found for "{selectedCategory}".</p>
                <p>Our AI is always searching. Check back soon!</p>
            </div>
        )}
      </Section>

      {selectedForCompare.length >= 2 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={handleCompareClick}
            className="flex items-center gap-3 bg-primary-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-primary-700 transition-all duration-300 animate-slide-up"
          >
            <CompareIcon className="h-6 w-6" />
            Compare Tools ({selectedForCompare.length})
          </button>
        </div>
      )}
    </div>
  );
};

export default ToolsView;