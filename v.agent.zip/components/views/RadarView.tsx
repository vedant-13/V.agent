import React, { useState, useEffect, useCallback } from 'react';
import { type RadarTool, type Tool } from '../../types';
import { getLiveToolLaunches } from '../../services/geminiService';
import { RADAR_CATEGORIES } from '../../constants';
import ToolCard from '../ui/ToolCard';
import Section from '../ui/Section';
import Spinner from '../ui/Spinner';
import Tag from '../ui/Tag';
import { RadarIcon, CompareIcon } from '../ui/icons';

interface RadarViewProps {
  onCompare: (tools: Tool[]) => void;
}

const RadarView: React.FC<RadarViewProps> = ({ onCompare }) => {
  const [tools, setTools] = useState<RadarTool[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);

  const loadRadar = useCallback(async () => {
    setLoading(true);
    setError(null);
    setTools([]); // Clear previous tools
    try {
      const data = await getLiveToolLaunches(selectedCategory);
      setTools(data);
    } catch (err) {
      setError('Failed to load the AI Tool Radar. Please try again later.');
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [selectedCategory]);

  useEffect(() => {
    loadRadar();
  }, [loadRadar]);
  
  const handleSelectForCompare = (toolName: string) => {
    setSelectedForCompare(prev => {
      if (prev.includes(toolName)) {
        return prev.filter(name => name !== toolName);
      }
      if (prev.length < 3) {
        return [...prev, toolName];
      }
      return prev;
    });
  };

  const handleCompareClick = () => {
    const toolsToCompare = tools.filter(tool => selectedForCompare.includes(tool.name));
    onCompare(toolsToCompare);
    setSelectedForCompare([]);
  }

  return (
    <div className="animate-fade-in p-6 md:p-8">
      <Section 
        title="Live Tool Launch Radar" 
        subtitle="The latest AI tools, just launched or gaining serious traction right now."
        icon={<RadarIcon className="h-8 w-8 text-primary-500" />}
      >
        <div className="bg-white/50 dark:bg-dark_ui-card/50 p-4 sm:p-6 rounded-lg shadow-inner border border-ui-border dark:border-dark_ui-border mb-8">
            <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
                <h3 className="text-xl font-bold">Explore by Category</h3>
                <Tag
                    label="Show All"
                    isActive={selectedCategory === 'All'}
                    onClick={() => setSelectedCategory('All')}
                />
            </div>
            <div className="space-y-4">
                {Object.entries(RADAR_CATEGORIES).map(([mainCategory, subCategories]) => (
                    <div key={mainCategory}>
                        <h4 className="font-semibold text-gray-700 dark:text-dark_ui-text-main mb-2">{mainCategory}</h4>
                        <div className="flex flex-wrap gap-2">
                            {subCategories.map(subCategory => (
                                <Tag
                                    key={subCategory}
                                    label={subCategory}
                                    isActive={selectedCategory === subCategory}
                                    onClick={() => setSelectedCategory(subCategory)}
                                />
                            ))}
                        </div>
                    </div>
                ))}
            </div>
        </div>

        {loading ? (
          <div className="flex justify-center items-center h-64">
            <Spinner />
          </div>
        ) : error ? (
          <div className="text-center text-red-500 py-20">{error}</div>
        ) : (
          <>
            <h4 className="text-lg font-semibold mb-6 text-center">
              Showing results for: <span className="text-primary-500 font-bold">{selectedCategory}</span>
            </h4>
            {tools.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {tools.map((tool, index) => (
                        <ToolCard 
                            key={`${tool.name}-${index}`} 
                            tool={tool}
                            onSelectForCompare={handleSelectForCompare}
                            isSelectedForCompare={selectedForCompare.includes(tool.name)}
                        />
                      ))}
                </div>
            ) : (
                <div className="text-center text-gray-500 dark:text-gray-400 py-20">
                    <p className="text-lg">Radar is clear for "{selectedCategory}".</p>
                    <p>Our AI is always scanning the horizon. Try another category or check back soon!</p>
                </div>
            )}
          </>
        )}
      </Section>

       {selectedForCompare.length >= 2 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={handleCompareClick}
            className="flex items-center gap-3 bg-primary-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-primary-700 transition-all duration-300 animate-slide-up"
          >
            <CompareIcon className="h-6 w-6" />
            Compare Tools ({selectedForCompare.length})
          </button>
        </div>
      )}
    </div>
  );
};

export default RadarView;