
import React from 'react';
import Section from '../ui/Section';
import { SendIcon } from '../ui/icons';

const ContactView: React.FC = () => {
    const contactEmail = 'vedantzalte13@gmail.com';

    return (
        <div className="animate-fade-in max-w-2xl mx-auto py-12">
            <header className="text-center mb-10">
                <h1 className="text-5xl font-extrabold text-gray-900 dark:text-white">Get In Touch</h1>
                <p className="mt-3 text-xl text-gray-600 dark:text-gray-300">
                    We’d love to hear from you.
                </p>
            </header>
            
            <div className="bg-white dark:bg-gray-800/50 p-8 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700/50">
                <p className="text-lg text-center text-gray-700 dark:text-gray-200 mb-6">
                    For general inquiries, feedback, or partnership opportunities, please don't hesitate to reach out. Your insights help us make V.agent better for everyone.
                </p>

                <div className="mt-6 flex justify-center">
                    <a
                        href={`mailto:${contactEmail}`}
                        className="inline-flex items-center gap-3 bg-primary-500 text-white font-bold py-3 px-8 rounded-full shadow-lg hover:bg-primary-600 transition-all duration-300 transform hover:scale-105"
                    >
                        <SendIcon className="h-5 w-5" />
                        <span>Contact Us via Email</span>
                    </a>
                </div>

                 <div className="text-center mt-8">
                    <p className="text-gray-500 dark:text-gray-400">You can reach us at:</p>
                    <a href={`mailto:${contactEmail}`} className="text-primary-500 font-semibold hover:underline">
                        {contactEmail}
                    </a>
                </div>
            </div>
        </div>
    );
};

export default ContactView;