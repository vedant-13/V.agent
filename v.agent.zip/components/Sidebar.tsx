import React from 'react';
import { type ActiveView } from '../types';
import { VAgentLogoIcon, DashboardIcon, ToolsIcon, RadarIcon, BrainCircuitIcon, SettingsIcon, HelpCenterIcon, SunIcon, MoonIcon, CloseIcon } from './ui/icons';

interface SidebarProps {
  activeView: ActiveView;
  setActiveView: (view: ActiveView) => void;
  theme: string;
  toggleTheme: () => void;
  isOpen: boolean;
  onClose: () => void;
  isMobile: boolean;
}

const NavItem: React.FC<{
    view: ActiveView;
    currentView: ActiveView;
    onClick: (view: ActiveView) => void;
    children: React.ReactNode;
    icon: React.ReactNode;
}> = ({ view, currentView, onClick, children, icon }) => {
    const isActive = view === currentView;
    const baseClasses = `flex items-center w-full px-4 py-3 text-sm font-medium rounded-lg transition-colors duration-200`;
    const activeClasses = 'bg-primary-500 text-ui-text-sidebar-active';
    const inactiveClasses = 'text-ui-text-sidebar hover:bg-slate-700 hover:text-white';

    return (
        <button
            onClick={() => onClick(view)}
            className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
        >
            <span className="mr-3">{icon}</span>
            {children}
        </button>
    );
};

const Sidebar: React.FC<SidebarProps> = ({ activeView, setActiveView, theme, toggleTheme, isOpen, onClose, isMobile }) => {
  const navItems = [
    { view: 'dashboard' as ActiveView, label: 'Dashboard', icon: <DashboardIcon className="h-5 w-5" /> },
    { view: 'tools' as ActiveView, label: 'All Tools', icon: <ToolsIcon className="h-5 w-5" /> },
    { view: 'radar' as ActiveView, label: 'Launch Radar', icon: <RadarIcon className="h-5 w-5" /> },
    { view: 'discover' as ActiveView, label: 'Agents', icon: <BrainCircuitIcon className="h-5 w-5" /> },
  ];

  const secondaryNavItems = [
     { view: 'about' as ActiveView, label: 'About', icon: <HelpCenterIcon className="h-5 w-5" /> },
     { view: 'contact' as ActiveView, label: 'Contact Us', icon: <SettingsIcon className="h-5 w-5" /> },
  ];
  
  const handleNavClick = (view: ActiveView) => {
    setActiveView(view);
    if(isMobile) {
        onClose();
    }
  }

  const sidebarClasses = isMobile 
    ? `fixed inset-0 z-50 transform transition-transform duration-300 ease-in-out ${isOpen ? 'translate-x-0' : '-translate-x-full'}`
    : 'relative';

  return (
    <aside className={`w-64 flex-shrink-0 bg-ui-sidebar flex flex-col p-4 ${sidebarClasses}`}>
      <div className="flex justify-between items-center mb-6">
          <div onClick={() => handleNavClick('dashboard')} className="flex items-center space-x-2 cursor-pointer p-2">
              <VAgentLogoIcon className="h-9 w-auto" />
              <span className="text-2xl font-bold text-white">V.agent</span>
          </div>
          {isMobile && (
              <button onClick={onClose} className="p-2 text-gray-400 hover:text-white">
                  <CloseIcon className="h-6 w-6"/>
              </button>
          )}
      </div>

      <nav className="flex-1 space-y-2">
        {navItems.map(item => (
            <NavItem key={item.view} view={item.view} currentView={activeView} onClick={handleNavClick} icon={item.icon}>
                {item.label}
            </NavItem>
        ))}
         <hr className="border-slate-700 my-4" />
         {secondaryNavItems.map(item => (
            <NavItem key={item.view} view={item.view} currentView={activeView} onClick={handleNavClick} icon={item.icon}>
                {item.label}
            </NavItem>
        ))}
      </nav>

      <div className="mt-auto">
        <div className="flex items-center justify-center p-2 rounded-lg bg-slate-800">
           <button onClick={() => toggleTheme()} className={`p-2 rounded-md transition-colors w-1/2 ${theme === 'light' ? 'bg-primary-500 text-white' : 'text-gray-400'}`}>
               <SunIcon className="h-5 w-5 mx-auto"/>
           </button>
           <button onClick={() => toggleTheme()} className={`p-2 rounded-md transition-colors w-1/2 ${theme === 'dark' ? 'bg-primary-500 text-white' : 'text-gray-400'}`}>
               <MoonIcon className="h-5 w-5 mx-auto"/>
           </button>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;