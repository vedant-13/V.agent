import React, { useState, useEffect, useCallback, useRef } from 'react';
import { type Tool, type NewsArticle, type ActiveView, type Ad } from '../types';
import { fetchData } from '../services/geminiService';
import ToolCard from './ui/ToolCard';
import NewsCard from './ui/NewsCard';
import Section from './ui/Section';
import Spinner from './ui/Spinner';
import { ArrowRightIcon, RadarIcon, SearchIcon, CompareIcon } from './ui/icons';
import UseCaseRecommender from './features/UseCaseRecommender';
import TrendForecaster from './features/TrendForecaster';

const SkeletonCard: React.FC = () => (
  <div className="bg-white dark:bg-dark_ui-card p-4 rounded-lg shadow-md animate-pulse">
    <div className="h-6 bg-gray-200 dark:bg-dark_ui-background rounded w-3/4 mb-2"></div>
    <div className="h-4 bg-gray-200 dark:bg-dark_ui-background rounded w-full mb-4"></div>
    <div className="h-4 bg-gray-200 dark:bg-dark_ui-background rounded w-1/2"></div>
  </div>
);

interface DashboardViewProps {
  setActiveView: (view: ActiveView) => void;
  onSearchClick: () => void;
  onCompare: (tools: Tool[]) => void;
}

// --- SPEECH SYNTHESIS HOOK ---
const useSpeechSynthesis = () => {
    const [isSpeaking, setIsSpeaking] = useState(false);
    const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

    const speak = useCallback((text: string) => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        if(isSpeaking) window.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.onstart = () => setIsSpeaking(true);
        utterance.onend = () => setIsSpeaking(false);
        utterance.onerror = (e) => {
            console.error("Speech synthesis error", e);
            setIsSpeaking(false);
        }
        utteranceRef.current = utterance;
        window.speechSynthesis.speak(utterance);
    }, [isSpeaking]);

    const cancel = useCallback(() => {
        if (typeof window === 'undefined' || !window.speechSynthesis) return;
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
    }, []);

    return { isSpeaking, speak, cancel };
};

const DashboardView: React.FC<DashboardViewProps> = ({ setActiveView, onSearchClick, onCompare }) => {
  const [topTools, setTopTools] = useState<Tool[]>([]);
  const [trendingNews, setTrendingNews] = useState<NewsArticle[]>([]);
  const [loadingTools, setLoadingTools] = useState(true);
  const [loadingNews, setLoadingNews] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [speakingArticle, setSpeakingArticle] = useState<string | null>(null);
  const [selectedForCompare, setSelectedForCompare] = useState<string[]>([]);

  const { isSpeaking, speak, cancel } = useSpeechSynthesis();

  const loadContent = useCallback(async () => {
    try {
      setLoadingTools(true);
      setLoadingNews(true);
      const [toolsData, newsData] = await Promise.all([
        fetchData<Tool>('weeklyTop'),
        fetchData<NewsArticle>('trendingNews')
      ]);
      setTopTools(toolsData);
      setTrendingNews(newsData);
    } catch (err) {
      setError('Failed to load content. The AI might be taking a nap.');
      console.error(err);
    } finally {
      setLoadingTools(false);
      setLoadingNews(false);
    }
  }, []);

  useEffect(() => {
    loadContent();
  }, [loadContent]);

  const handleSelectForCompare = (toolName: string) => {
    setSelectedForCompare(prev => {
      if (prev.includes(toolName)) {
        return prev.filter(name => name !== toolName);
      }
      if (prev.length < 3) { return [...prev, toolName]; }
      return prev;
    });
  };

  const handleCompareClick = () => {
    const toolsToCompare = topTools.filter(tool => selectedForCompare.includes(tool.name));
    onCompare(toolsToCompare);
    setSelectedForCompare([]);
  }

  const playSummary = (text: string, headline: string) => {
      if (isSpeaking && speakingArticle === headline) {
          cancel();
          setSpeakingArticle(null);
      } else {
          speak(text);
          setSpeakingArticle(headline);
      }
  };

  useEffect(() => {
      if(!isSpeaking) {
          setSpeakingArticle(null);
      }
  }, [isSpeaking]);

  if (error) {
    return <div className="text-center text-red-500 py-20">{error}</div>;
  }

  return (
    <div className="p-4 md:p-8 space-y-12 animate-fade-in">
       <div className="text-center py-8">
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight text-gray-900 dark:text-white">
          Discover What's <span className="text-primary-500">Next in AI</span>
        </h1>
        <p className="mt-4 text-lg md:text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
          Your intelligent gateway to the latest AI tools, news, and breakthroughs, curated and summarized by AI.
        </p>
        <button 
          onClick={onSearchClick}
          className="mt-6 inline-flex items-center gap-2 bg-primary-500 text-white font-semibold py-3 px-6 rounded-lg hover:bg-primary-600 transition-colors shadow-lg hover:shadow-xl"
        >
          <SearchIcon className="h-5 w-5"/>
          Search for an AI Tool
        </button>
      </div>

      <UseCaseRecommender />
      <TrendForecaster />

      <Section 
        title="🏆 Weekly Top Tools" 
        subtitle="The most popular AI tools of the week, picked by our AI agent."
        headerAction={
          <button onClick={() => setActiveView('tools')} className="flex items-center space-x-2 text-sm font-medium text-primary-500 hover:text-primary-600 dark:hover:text-primary-400">
            <span>View All Tools</span>
            <ArrowRightIcon className="h-4 w-4" />
          </button>
        }
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {loadingTools
            ? Array.from({ length: 8 }).map((_, i) => <SkeletonCard key={i} />)
            : topTools.map((item, index) => (
                <ToolCard 
                    key={`${item.name}-${index}`} 
                    tool={item} 
                    onSelectForCompare={handleSelectForCompare}
                    isSelectedForCompare={selectedForCompare.includes(item.name)}
                />
              ))}
        </div>
      </Section>
      
      <Section 
        title="📰 Trending AI News" 
        subtitle="The latest headlines and summaries from the world of AI."
      >
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {loadingNews
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : trendingNews.map((article, index) => (
                <NewsCard 
                  key={`${article.headline}-${index}`} 
                  article={article} 
                  onPlaySummary={playSummary}
                  isCardSpeaking={speakingArticle === article.headline}
                />
              ))}
        </div>
      </Section>
      
      {selectedForCompare.length >= 2 && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-40">
          <button 
            onClick={handleCompareClick}
            className="flex items-center gap-3 bg-primary-600 text-white font-bold py-3 px-6 rounded-full shadow-lg hover:bg-primary-700 transition-all duration-300 animate-slide-up"
          >
            <CompareIcon className="h-6 w-6" />
            Compare Tools ({selectedForCompare.length})
          </button>
        </div>
      )}
    </div>
  );
};

export default DashboardView;