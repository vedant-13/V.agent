
import React, { useState, useRef, useEffect } from 'react';
import { ChatIcon, CloseIcon, SendIcon } from './ui/icons';
import { sendMessageToChat } from '../services/geminiService';
import { type ChatMessage } from '../types';
import Spinner from './ui/Spinner';

const ChatAssistant: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(scrollToBottom, [messages]);
  
  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setIsLoading(true);
      sendMessageToChat("Hello", (chunk) => {
         setMessages([{ role: 'model', content: chunk }]);
      }).finally(() => setIsLoading(false));
    }
  }, [isOpen, messages.length]);

  const handleSend = async () => {
    if (input.trim() === '' || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    let fullResponse = '';
    const modelMessage: ChatMessage = { role: 'model', content: '' };
    setMessages(prev => [...prev, modelMessage]);

    await sendMessageToChat(input, (chunk) => {
      fullResponse += chunk;
      setMessages(prev =>
        prev.map((msg, index) =>
          index === prev.length - 1 ? { ...msg, content: fullResponse } : msg
        )
      );
    });

    setIsLoading(false);
  };

  return (
    <>
      <div className="fixed bottom-6 right-6 z-50">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="bg-primary-500 text-white rounded-full p-4 shadow-lg hover:bg-primary-600 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-transform duration-200 hover:scale-110"
          aria-label="Toggle AI Assistant"
        >
          {isOpen ? <CloseIcon className="h-8 w-8" /> : <ChatIcon className="h-8 w-8" />}
        </button>
      </div>

      {isOpen && (
        <div className="fixed bottom-24 right-6 z-50 w-full max-w-sm h-[60vh] bg-white dark:bg-gray-800 rounded-lg shadow-2xl flex flex-col animate-fade-in">
          <header className="bg-primary-500 text-white p-4 rounded-t-lg flex justify-between items-center">
            <h3 className="font-bold text-lg">V.agent Assistant</h3>
          </header>

          <div className="flex-grow p-4 overflow-y-auto">
            <div className="space-y-4">
              {messages.map((msg, index) => (
                <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                  <div
                    className={`max-w-xs md:max-w-sm rounded-lg px-4 py-2 text-white ${
                      msg.role === 'user' ? 'bg-blue-500' : 'bg-gray-600 dark:bg-gray-700'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                  </div>
                </div>
              ))}
              {isLoading && messages[messages.length-1]?.role === 'user' && (
                <div className="flex justify-start">
                   <div className="bg-gray-600 dark:bg-gray-700 rounded-lg px-4 py-2">
                       <Spinner size="sm" />
                   </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>
          </div>

          <footer className="p-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask for a tool..."
                className="w-full p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-primary-500"
                disabled={isLoading}
              />
              <button
                onClick={handleSend}
                disabled={isLoading}
                className="bg-primary-500 text-white p-2 rounded-full disabled:bg-primary-300 disabled:cursor-not-allowed hover:bg-primary-600 transition-colors"
              >
                <SendIcon className="h-6 w-6" />
              </button>
            </div>
          </footer>
        </div>
      )}
    </>
  );
};

export default ChatAssistant;