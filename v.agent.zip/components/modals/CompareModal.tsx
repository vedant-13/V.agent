import React, { useState, useEffect, useCallback } from 'react';
import { type Tool, type ComparisonData } from '../../types';
import { compareTools } from '../../services/geminiService';
import { CloseIcon, CheckIcon } from '../ui/icons';
import Spinner from '../ui/Spinner';

interface CompareModalProps {
  isOpen: boolean;
  onClose: () => void;
  tools: Tool[];
}

const CompareModal: React.FC<CompareModalProps> = ({ isOpen, onClose, tools }) => {
  const [data, setData] = useState<ComparisonData[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchComparison = useCallback(async () => {
    if (tools.length < 2) return;
    setLoading(true);
    setData(null);
    setError(null);
    try {
      const toolNames = tools.map(t => t.name);
      const result = await compareTools(toolNames);
      if(result && result.length > 0) {
        // Align data with the order of tools passed in
        const sortedResult = tools.map(tool => result.find(r => r.toolName.toLowerCase() === tool.name.toLowerCase())).filter(Boolean) as ComparisonData[];
        setData(sortedResult);
      } else {
        setError("Sorry, the AI couldn't generate a comparison for these tools.");
      }
    } catch (err) {
      setError("An error occurred while generating the comparison.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [tools]);

  useEffect(() => {
    if (isOpen) {
      fetchComparison();
    }
  }, [isOpen, fetchComparison]);

  if (!isOpen) return null;

  const features = ["Pricing", "Key Features", "AI Model", "Limitations", "Integrations"];

  return (
    <div className="fixed inset-0 bg-black/60 dark:bg-black/80 z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose} role="dialog" aria-modal="true">
      <div 
        className="w-full max-w-6xl h-[90vh] bg-white dark:bg-gray-800 rounded-lg shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="p-4 border-b border-gray-200 dark:border-gray-700 flex justify-between items-center flex-shrink-0">
          <h3 className="font-bold text-lg text-gray-900 dark:text-white">Tool Comparison</h3>
          <button onClick={onClose} className="p-2 rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700" aria-label="Close comparison">
            <CloseIcon className="h-6 w-6" />
          </button>
        </header>
        
        <div className="flex-grow overflow-auto">
          {loading ? (
            <div className="flex justify-center items-center h-full"><Spinner size="lg" /></div>
          ) : error ? (
            <div className="flex justify-center items-center h-full text-red-500 p-8">{error}</div>
          ) : data ? (
            <table className="w-full text-sm text-left text-gray-500 dark:text-gray-400 border-collapse">
              <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-300 sticky top-0">
                <tr>
                  <th scope="col" className="px-6 py-3 w-1/5">Feature</th>
                  {data.map((toolData, index) => (
                    <th key={index} scope="col" className="px-6 py-3 text-center">
                        <div className="flex flex-col items-center gap-2">
                            <span className="text-2xl">{tools.find(t=>t.name.toLowerCase() === toolData.toolName.toLowerCase())?.icon}</span>
                            <span className="font-bold text-base">{toolData.toolName}</span>
                        </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {features.map(feature => (
                  <tr key={feature} className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600/30">
                    <th scope="row" className="px-6 py-4 font-bold text-gray-900 dark:text-white align-top">{feature}</th>
                    {data.map((toolData, index) => {
                       let content;
                       switch (feature) {
                            case "Pricing": content = <p>{toolData.pricing}</p>; break;
                            case "AI Model": content = <p>{toolData.model}</p>; break;
                            case "Key Features": content = <ul className="list-disc list-inside space-y-1">{toolData.features.map((f,i) => <li key={i}>{f}</li>)}</ul>; break;
                            case "Limitations": content = <ul className="list-disc list-inside space-y-1">{toolData.limitations.map((l,i) => <li key={i}>{l}</li>)}</ul>; break;
                            case "Integrations": content = toolData.integrations.length > 0 ? <div className="flex flex-wrap gap-2">{toolData.integrations.map((item,i) => <span key={i} className="bg-gray-200 dark:bg-gray-600 px-2 py-0.5 rounded-md text-xs">{item}</span>)}</div> : <p>N/A</p>; break;
                            default: content = null;
                       }
                       return <td key={index} className="px-6 py-4 align-top">{content}</td>;
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          ) : null}
        </div>
      </div>
    </div>
  );
};

export default CompareModal;