export const TOOL_CATEGORIES = ["Text", "Image", "Video", "Code", "Audio", "Productivity", "Marketing", "Research", "Agents"] as const;

export const TOOL_PRICING = ["Free", "Freemium", "Paid"] as const;

export const GEMINI_TEXT_MODEL = "gemini-2.5-flash";
export const GEMINI_CHAT_MODEL = "gemini-2.5-flash";

export const REGIONS = ["Worldwide", "USA", "Europe", "Asia", "UK"] as const;
export const NEWS_CATEGORIES = ["AI", "Technology", "Startups", "Science", "Business"] as const;
export const NEWS_FILTERS = ["Trending", "Latest", "Popular"] as const;

export const RADAR_CATEGORIES = {
  "💼 Work & Productivity": ["Task Automation", "Notion Tools", "Meeting AI", "Calendar & Scheduling", "Email Assistant", "Resume/Job Tools", "Google Docs/Sheets Enhancers", "File Converters"],
  "🧠 AI Creativity & Content": ["AI Image Generators", "AI Video Creators", "Music & Song Generators", "Prompt Generators", "AI Meme Creators", "Social Media Post Creators", "Blogging/Writing Tools", "AI Character Builders"],
  "🖥️ Developer Tools": ["Code Copilots", "API Generators", "SQL Query Builders", "UI/UX Design Tools", "AI Website Builders", "Frontend/Backend Helpers", "Prompt to Code Tools", "IDE Extensions", "Web-Dev Tools"],
  "🧬 Learning & Education": ["AI Tutors", "Exam Solvers", "Note Summarizers", "PDF Explainers", "Language Learning", "Flashcard Makers", "Research Assistants", "Course Creators"],
  "🛠️ Utility Tools": ["PDF, Word, Excel Converters", "Image Compressors", "Background Removers", "QR Code Generators", "Video Editors", "Resume Builders", "Link Shorteners"],
  "📲 Social Media & Marketing": ["SEO Optimizers", "Hashtag Generators", "Viral Reels Script Writers", "Thumbnail Creators", "Caption Writers", "Engagement Tools", "Analytics Trackers"],
  "🔐 Security & Privacy": ["Password Generators", "Face Blur Tools", "Secure Email Tools", "VPN & Proxy Helpers", "File Encryptors", "Anti-Phishing Checkers"],
  "🛍️ E-commerce & Business": ["Product Description Generators", "Review Summary AI", "Dropshipping Helpers", "Pricing Tools", "Chatbot for Store", "Shopify + Amazon Plugins", "Sales Funnel Creators"],
  "🎨 Design & Branding": ["Logo Generators", "Brand Name AI", "Color Scheme Tools", "Font Pairing Tools", "Poster / Banner Designers", "Mockup Creators"],
  "🤖 Agents & Automation": ["Auto Email Responder", "Research Agent", "Job Seeker Agent", "Daily Planner Agent", "Prompt Research Agent", "Website Testing Agent"],
  "⚡️ Bonus Categories": ["Startup Tools", "Finance & Investing Tools", "Game Development AI", "Mental Health & Wellness", "Photography AI Tools", "Book & Script Generators"]
};