

import { GoogleGenAI, Type, Chat, GenerateContentResponse } from "@google/genai";
import { type Tool, type NewsArticle, type ApiDataType, type RadarTool, type ToolWorkflow, type AITrend, type ComparisonData } from '../types';
import { TOOL_CATEGORIES, GEMINI_TEXT_MODEL, GEMINI_CHAT_MODEL, TOOL_PRICING } from '../constants';

if (!process.env.API_KEY) {
  console.error("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

const urlDescription = "The fully-qualified, verifiable, and publicly accessible homepage URL (e.g., https://example.com). This MUST be a real, working link. Do not invent or guess URLs.";

const toolSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING, description: "The name of the tool." },
    description: { type: Type.STRING, description: "A concise, one-sentence summary of what the tool does." },
    category: { type: Type.STRING, enum: TOOL_CATEGORIES, description: "The primary category of the tool." },
    url: { type: Type.STRING, description: urlDescription },
    icon: { type: Type.STRING, description: "A single emoji that represents the tool's function." },
    pricing: { type: Type.STRING, enum: TOOL_PRICING, description: "The pricing model of the tool." },
  },
  required: ["name", "description", "category", "url", "icon", "pricing"],
};

const newsSchema = {
    type: Type.OBJECT,
    properties: {
        headline: { type: Type.STRING, description: "The main headline of the news article." },
        summary: { type: Type.STRING, description: "A 100-150 character summary of the news." },
        source: { type: Type.STRING, description: "The original source name (e.g., 'TechCrunch')." },
        url: { type: Type.STRING, description: urlDescription },
        icon: { type: Type.STRING, description: "A single emoji that represents the news topic." },
        imageUrl: { type: Type.STRING, description: "A valid, public URL for a relevant, high-quality background image for the article." },
        date: { type: Type.STRING, description: "The publication date in 'YYYY-MM-DD' format. This MUST be a recent date (within the last 7 days)." }
    },
    required: ["headline", "summary", "source", "url", "icon", "imageUrl", "date"],
};

const newsSearchResponseSchema = {
  type: Type.OBJECT,
  properties: {
    summary: { type: Type.STRING, description: "A high-level summary of the news found, based on the user's query." },
    articles: {
      type: Type.ARRAY,
      items: newsSchema
    }
  },
  required: ['summary', 'articles']
};


const getPrompt = (dataType: 'latestTools' | 'weeklyTop'): string => {
  const promptSuffix = "\n\nCrucially, every URL provided MUST be a real, valid, and tested link to the tool's or article's official page. Do not provide placeholder or fictional URLs.";
  switch (dataType) {
    case 'latestTools':
      return `Act as an AI research agent. Find the 12 most interesting and recently launched AI tools from sources like Product Hunt, Hacker News, and developer communities. For each tool, provide its name, a one-sentence description, a relevant category from the provided list, its URL, a representative emoji, and its pricing.` + promptSuffix;
    case 'weeklyTop':
      return `Act as an AI trend analyst. Identify the top 8 AI tools that generated the most buzz over the past week. Consider developer communities and product launch sites. For each tool, provide its name, a one-sentence description, a relevant category from the provided list, its URL, a representative emoji, and its pricing.` + promptSuffix;
    default:
      throw new Error("Invalid data type requested.");
  }
};


export const fetchData = async <T,> (dataType: ApiDataType): Promise<T[]> => {
    try {
        if (dataType === 'trendingNews') {
            const { articles } = await searchAINews({ query: 'Trending AI and Technology News' });
            return articles as T[];
        }

        const prompt = getPrompt(dataType);
        const schema = toolSchema;

        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: schema,
                },
                 thinkingConfig: { thinkingBudget: 0 }
            },
        });
        
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as T[];

    } catch (error) {
        console.error(`Error fetching ${dataType}:`, error);
        return [];
    }
};

export const searchAITools = async (params: {
  query: string;
  category: string;
  pricing: string;
}): Promise<Tool[]> => {
  const { query, category, pricing } = params;

  let prompt = `Act as an expert AI tool researcher. Find up to 8 AI tools based on the following criteria:\n`;
  if(query) {
    prompt += `- User query: "${query}"\n`;
  } else {
    prompt += `- Find popular and useful tools.\n`
  }
  if (category && category !== 'All') {
    prompt += `- Category: "${category}"\n`;
  }
  if (pricing && pricing !== 'All') {
    prompt += `- Pricing model: "${pricing}"\n`;
  }
  prompt += "For each tool, provide its name, a one-sentence description, a relevant category, a real URL, a representative emoji, and its pricing model.";
  prompt += "\n\nCrucially, every URL provided MUST be a real, valid, and tested link to the tool's official page. Do not provide placeholder or fictional URLs.";

  try {
    const response = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: toolSchema,
        },
      },
    });

    const jsonText = response.text.trim();
    return JSON.parse(jsonText) as Tool[];
  } catch (error) {
    console.error("Error searching AI tools:", error);
    return [];
  }
};

export const searchAINews = async (params: { 
    query: string; 
    category?: string; 
    filterType?: string; 
    region?: string; 
}): Promise<{articles: NewsArticle[], text: string}> => {
    const { query, category, filterType, region } = params;
    const currentDate = new Date().toISOString().split('T')[0];
    
    let prompt = `Act as an expert AI news analyst. Today's date is ${currentDate}. Find 6-8 of the most significant and recent news articles based on the following topic: "${query}".`;
    prompt += `\n\n**CRITICAL INSTRUCTION: The publication date for ALL articles MUST be within the last 7 days from today's date (${currentDate}).** You must not return any news older than 7 days. Prioritize the absolute latest, trending, and most popular stories within this strict timeframe. Verify the publication date before including an article.`;

    if (category && category !== 'AI' && category !== 'All') prompt += `\nFocus on the '${category}' category.`
    if (filterType && filterType !== 'All') prompt += `\nThe articles should be '${filterType}'.`
    if (region && region !== 'Worldwide' && region !== 'All') prompt += `\nSource articles primarily from the '${region}' region.`

    prompt += "\n\nFirst, provide a high-level summary of the findings. Then, for each article, provide the data requested in the schema. Ensure all URLs are real, verifiable links.";

    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: newsSearchResponseSchema
            },
        });
        
        const responseText = response.text.trim();
        const parsed = JSON.parse(responseText);
        return { articles: parsed.articles || [], text: parsed.summary || '' };

    } catch (error) {
        console.error("Error searching AI news:", error);
        return { articles: [], text: '' };
    }
};


export const recommendToolWorkflow = async (goal: string): Promise<ToolWorkflow | null> => {
    const prompt = `Act as an expert AI workflow strategist. A user wants to achieve the following goal: "${goal}". 
    Recommend a sequence of 2-4 real AI tools that can be used together to achieve this.
    For each tool in the workflow, provide its real name, its URL, a single emoji icon, and a brief reason for why it's included in this specific step of the process.
    \n\nCrucially, every URL provided MUST be a real, valid, and tested link to the tool's official page. Do not provide placeholder or fictional URLs.`;
    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        goal: { type: Type.STRING },
                        workflow: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    name: { type: Type.STRING },
                                    icon: { type: Type.STRING },
                                    reason: { type: Type.STRING },
                                    url: { type: Type.STRING, description: urlDescription },
                                },
                                required: ["name", "icon", "reason", "url"],
                            },
                        },
                    },
                    required: ["goal", "workflow"],
                },
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as ToolWorkflow;
    } catch (error) {
        console.error("Error recommending tool workflow:", error);
        return null;
    }
};

export const getLiveToolLaunches = async (category: string = 'All'): Promise<RadarTool[]> => {
    let prompt = `Act as a "Live Tool Launch Radar" agent. Scan ProductHunt, GitHub, and Twitter for AI tools that are either newly launched in the last 24-48 hours or are rapidly gaining traction (e.g., stars on GitHub).`;
    
    if (category && category !== 'All') {
        prompt += ` Focus specifically on tools in the following category: "${category}".`;
    }

    prompt += `\nIdentify 8-12 relevant tools. For each tool, assign a status of "🚀 Just Launched" or "🔥 Trending". Provide the tool's name, a one-sentence description, its most relevant primary category from the available list, its URL, an emoji icon, its pricing model, and its status.`;
    prompt += "\n\nCrucially, every URL provided MUST be a real, valid, and tested link to the tool's official page. Do not provide placeholder or fictional URLs.";
    
    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        ...toolSchema,
                        properties: {
                            ...toolSchema.properties,
                            status: { type: Type.STRING, enum: ["🚀 Just Launched", "🔥 Trending"] }
                        },
                        required: [...toolSchema.required, "status"]
                    }
                },
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as RadarTool[];
    } catch (error) {
        console.error(`Error getting live tool launches for category "${category}":`, error);
        return [];
    }
};

export const fetchAgentTools = async (category: string = 'All'): Promise<Tool[]> => {
    let prompt = `Act as an AI agent specialist. Find 8-12 of the most popular and recently updated AI Agent tools. These are tools that act autonomously or semi-autonomously to perform tasks for users.`;
    if (category && category !== 'All') {
        prompt += ` Focus specifically on agents in the category: "${category}". Examples include research agents, automation agents, or for specific tasks like email or job searching.`;
    }
    prompt += `\nFor each tool, provide its name, a one-sentence description of its agent capabilities, its primary category which MUST be 'Agents', its real URL, a representative emoji, and its pricing model.`;
    prompt += "\n\nCrucially, every URL provided MUST be a real, valid, and tested link to the tool's official page. Do not provide placeholder or fictional URLs.";

    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        ...toolSchema,
                        properties: {
                            ...toolSchema.properties,
                            category: { type: Type.STRING, enum: ["Agents"] }
                        },
                        required: [...toolSchema.required]
                    }
                },
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as Tool[];
    } catch (error) {
        console.error(`Error fetching agent tools for category "${category}":`, error);
        return [];
    }
};

export const getAITrends = async (): Promise<AITrend[]> => {
    const prompt = `Act as an AI market trend analyst. Analyze signals from Google Trends, GitHub repository activity, ProductHunt launches, and tech news buzz.
    Based on this analysis, predict 3-4 upcoming hot categories or trends in AI for the next 6-12 months.
    For each predicted trend, provide a name, a confidence score ('High', 'Medium', or 'Low'), and a brief 1-2 sentence justification for your prediction, citing the types of signals you're observing.`;
    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            name: { type: Type.STRING, description: "Name of the predicted trend." },
                            justification: { type: Type.STRING, description: "Justification for the prediction." },
                            confidence: { type: Type.STRING, enum: ['High', 'Medium', 'Low'], description: "Confidence level in the prediction." },
                        },
                        required: ["name", "justification", "confidence"],
                    },
                },
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as AITrend[];
    } catch (error) {
        console.error("Error getting AI trends:", error);
        return [];
    }
};

export const compareTools = async (toolNames: string[]): Promise<ComparisonData[]> => {
    const prompt = `Act as a tech analyst. Provide a detailed, side-by-side comparison for the following AI tools: ${toolNames.join(', ')}.
    For each tool, research and provide its pricing summary, key features (as a list of strings), the primary AI model used (if known, otherwise 'Proprietary' or 'N/A'), its main limitations (list), and key integrations (list).
    Structure the output as a JSON array, with one object per tool.`;

    try {
        const response = await ai.models.generateContent({
            model: GEMINI_TEXT_MODEL,
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            toolName: { type: Type.STRING },
                            pricing: { type: Type.STRING, description: "A brief summary of the pricing, e.g., 'Starts free, Pro at $20/mo'." },
                            features: { type: Type.ARRAY, items: { type: Type.STRING } },
                            model: { type: Type.STRING, description: "e.g., 'GPT-4', 'Claude 3', 'Proprietary'" },
                            limitations: { type: Type.ARRAY, items: { type: Type.STRING } },
                            integrations: { type: Type.ARRAY, items: { type: Type.STRING } },
                        },
                        required: ["toolName", "pricing", "features", "model", "limitations", "integrations"],
                    },
                },
            },
        });
        const jsonText = response.text.trim();
        return JSON.parse(jsonText) as ComparisonData[];
    } catch (error) {
        console.error("Error comparing tools:", error);
        return [];
    }
};

// Chat Assistant Service (remains unchanged)
let chat: Chat | null = null;
const initializeChat = (): Chat => {
    if (!chat) {
        chat = ai.chats.create({
            model: GEMINI_CHAT_MODEL,
            config: {
                systemInstruction: `You are 'V.agent', a friendly and knowledgeable AI assistant. Your purpose is to help users discover the best AI tools for their needs.
                - Start with a friendly greeting.
                - Ask clarifying questions to understand the user's goal.
                - Suggest specific AI tools and describe how they can help.
                - Keep your responses concise and easy to understand.
                - Use emojis to make the conversation more engaging.`,
            },
        });
    }
    return chat;
}

export const sendMessageToChat = async (message: string, onChunk: (chunk: string) => void): Promise<void> => {
    try {
        const chatInstance = initializeChat();
        const stream = await chatInstance.sendMessageStream({ message });
        for await (const chunk of stream) {
            onChunk(chunk.text);
        }
    } catch (error) {
        console.error("Error sending message to chat:", error);
        onChunk("I'm sorry, I seem to be having some trouble right now. Please try again later. 🛠️");
    }
};