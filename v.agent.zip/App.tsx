import React, { useState, useMemo, useEffect } from 'react';
import { useTheme } from './hooks/useTheme';
import Sidebar from './components/Sidebar';
import ChatAssistant from './components/ChatAssistant';
import DashboardView from './components/DashboardView';
import ToolsView from './components/views/ToolsView';
import RadarView from './components/views/RadarView';
import AboutView from './components/views/AboutView';
import ContactView from './components/views/ContactView';
import PrivacyView from './components/views/PrivacyView';
import TermsView from './components/views/TermsView';
import DiscoverView from './components/views/DiscoverView';
import { type ActiveView, type Tool, type ComparisonData } from './types';
import SearchModal from './components/SearchModal';
import CompareModal from './components/modals/CompareModal';
import MobileHeader from './components/MobileHeader';

const App: React.FC = () => {
  const [theme, toggleTheme] = useTheme();
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  
  const [isMobile, setIsMobile] = useState(window.innerWidth < 1024);

   useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth < 1024);
      if (window.innerWidth >= 1024) {
        setSidebarOpen(false); // Close sidebar when resizing to desktop
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);


  // State for Comparison Modal
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [toolsToCompare, setToolsToCompare] = useState<Tool[]>([]);

  const handleOpenCompareModal = (tools: Tool[]) => {
    setToolsToCompare(tools);
    setIsCompareModalOpen(true);
  };
  
  const handleCloseCompareModal = () => {
    setIsCompareModalOpen(false);
    setToolsToCompare([]);
  }

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeView]);

  const CurrentView = useMemo(() => {
    switch (activeView) {
      case 'tools':
        return <ToolsView onCompare={handleOpenCompareModal} />;
      case 'radar':
        return <RadarView onCompare={handleOpenCompareModal} />;
      case 'discover':
        return <DiscoverView onCompare={handleOpenCompareModal} />;
      case 'about':
        return <AboutView />;
      case 'contact':
        return <ContactView />;
      case 'privacy':
        return <PrivacyView />;
      case 'terms':
        return <TermsView />;
      case 'dashboard':
      default:
        return <DashboardView 
                  setActiveView={setActiveView} 
                  onSearchClick={() => setIsSearchOpen(true)}
                  onCompare={handleOpenCompareModal}
                />;
    }
  }, [activeView]);

  return (
    <div className="flex h-screen w-full font-sans bg-ui-background dark:bg-dark_ui-background">
      <Sidebar 
        activeView={activeView} 
        setActiveView={setActiveView}
        theme={theme}
        toggleTheme={toggleTheme}
        isOpen={isSidebarOpen}
        onClose={() => setSidebarOpen(false)}
        isMobile={isMobile}
      />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        {isMobile && (
          <MobileHeader 
            onMenuClick={() => setSidebarOpen(true)}
            theme={theme}
            toggleTheme={toggleTheme}
            setActiveView={setActiveView}
          />
        )}
        <main className="flex-1 overflow-y-auto">
          {CurrentView}
        </main>
      </div>

      <ChatAssistant />
      <SearchModal isOpen={isSearchOpen} onClose={() => setIsSearchOpen(false)} />
      <CompareModal 
        isOpen={isCompareModalOpen}
        onClose={handleCloseCompareModal}
        tools={toolsToCompare}
      />
    </div>
  );
};

export default App;