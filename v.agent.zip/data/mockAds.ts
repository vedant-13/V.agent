import { type Ad } from '../types';

export const mockAds: Ad[] = [
  {
    id: 'ad-starlight-cloud',
    company: 'Starlight Cloud',
    headline: 'Deploy Your AI Models Faster Than Ever',
    description: 'Experience blazing-fast inference with our GPU-powered cloud infrastructure. Get started with $300 in free credits.',
    imageUrl: 'https://images.unsplash.com/photo-1554415707-6e8cfc93fe23?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ctaText: 'Claim Free Credits',
    ctaUrl: '#',
  },
  {
    id: 'ad-dev-summit-2024',
    company: 'DevRelations Inc.',
    headline: 'Connect at the Global Dev Summit 2024',
    description: 'Join thousands of developers, innovators, and leaders shaping the future of technology. Early bird tickets available now.',
    imageUrl: 'https://images.unsplash.com/photo-1541532713592-79a0317b6b77?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ctaText: 'Get Your Ticket',
    ctaUrl: '#',
  },
   {
    id: 'ad-cybersafe',
    company: 'CyberSafe',
    headline: 'Protect Your Digital Life with One Click',
    description: 'Our award-winning security suite keeps you safe from threats so you can browse, shop, and work with peace of mind.',
    imageUrl: 'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?q=80&w=800&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    ctaText: 'Learn More',
    ctaUrl: '#',
  },
];
