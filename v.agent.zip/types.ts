import { type TOOL_CATEGORIES, type TOOL_PRICING } from './constants';

export interface Tool {
  name: string;
  description: string;
  category: (typeof TOOL_CATEGORIES)[number];
  url: string;
  icon: string;
  pricing?: (typeof TOOL_PRICING)[number];
}

export interface NewsArticle {
  headline: string;
  summary: string;
  source: string;
  url: string;
  icon: string;
  imageUrl?: string;
  date: string;
}

export interface ChatMessage {
    role: 'user' | 'model';
    content: string;
}

export interface SearchMessage {
  id: string;
  role: 'user' | 'model';
  text?: string;
  options?: {
    label: string;
    action: string;
    payload?: any;
  }[];
  results?: Tool[];
  resultType?: 'tools';
  sources?: { uri: string; title: string }[];
}

export type ApiDataType = 'latestTools' | 'weeklyTop' | 'trendingNews';

export type ActiveView = 'dashboard' | 'tools' | 'radar' | 'discover' | 'about' | 'contact' | 'privacy' | 'terms';

export interface RadarTool extends Tool {
  status: '🚀 Just Launched' | '🔥 Trending';
}

export interface RecommendedTool {
  name: string;
  icon: string;
  reason: string;
  url: string;
}

export interface ToolWorkflow {
  goal: string;
  workflow: RecommendedTool[];
}

export interface AITrend {
  name: string;
  justification: string;
  confidence: 'High' | 'Medium' | 'Low';
}

export interface Ad {
  id: string;
  company: string;
  headline: string;
  description: string;
  imageUrl: string;
  ctaText: string;
  ctaUrl: string;
}

export interface ComparisonData {
  toolName: string;
  pricing: string;
  features: string[];
  model: string;
  limitations: string[];
  integrations: string[];
}